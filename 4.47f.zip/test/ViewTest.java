import org.junit.Test;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;

import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;

import static junit.framework.TestCase.assertEquals;


/**
 * Tests to see if the pyramid view is being built correctly.
 */

public class ViewTest {
  @Test
  public void TestView() {

    BasicPyramidSolitaire test1 = new BasicPyramidSolitaire();
    test1.startGame(test1.getDeck(), false, 5, 1);
    PyramidSolitaireTextualView model1 = new PyramidSolitaireTextualView(test1);


    BasicPyramidSolitaire test2 = new BasicPyramidSolitaire();
    test2.startGame(test2.getDeck(), false, 6, 1);
    PyramidSolitaireTextualView model2 = new PyramidSolitaireTextualView(test2);


    BasicPyramidSolitaire test3 = new BasicPyramidSolitaire();
    PyramidSolitaireTextualView model3 = new PyramidSolitaireTextualView(test3);

    assertEquals("        A♠\n" +
            "      A♦  A♥\n" +
            "    A♣  2♠  2♦\n" +
            "  2♥  2♣  3♠  3♦\n" +
            "3♥  3♣  4♠  4♦  4♥\n" +
            "Draw: 4♣", model1.toString());
    assertEquals(model3.toString(), "");

    assertEquals(model1.toString(), (model1.toString()));
  }


}

