import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import java.util.Collections;

import java.util.List;
import java.util.Random;


import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;

import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;

/**
 * Tests for the public methods in the builder interface.
 */
public class PyramidTest {

  ArrayList<ArrayList<Card>> pyramid;
  ArrayList<ArrayList<Card>> pyramid01;
  ArrayList<ArrayList<Card>> pyramidk;
  ArrayList<ArrayList<Card>> pyramidwok;
  ArrayList<ArrayList<Card>> pyramidd2d1;
  Card c1;
  Card c2;
  Card c3;
  Card c4;
  Card c5;
  Card c6;
  Card c7;
  Card c8;
  Card c9;
  Card c10;
  Card e1;

  Card c02;
  Card c03;

  Card k1;

  ArrayList<Card> deck1; // 1-5
  ArrayList<Card> deck2; // 6-10
  ArrayList<Card> deck3; // 1-10
  ArrayList<Card> deck4;
  ArrayList<Card> deck5;
  ArrayList<Card> deckee;
  ArrayList<Card> deckKing;
  ArrayList<Card> emptyDeck;
  ArrayList<Card> deckw010;


  PyramidSolitaireModel test1;
  PyramidSolitaireModel test2;
  PyramidSolitaireModel test3;
  PyramidSolitaireModel test4;
  PyramidSolitaireModel test5;
  PyramidSolitaireModel test6;
  PyramidSolitaireModel test7;
  PyramidSolitaireModel test8;
  PyramidSolitaireModel test9;


  @Before
  public void setUp() {
    //cards
    this.c1 = new Card('♣', "A");
    this.c2 = new Card('♦', "K");
    this.c3 = new Card('♦', "Q");
    this.c4 = new Card('♦', "5");
    this.c5 = new Card(5, 1, 2, '♣');
    this.c6 = new Card(6, 2, 4, '♦');
    this.c7 = new Card(7, 3, 3, '♥');
    this.c8 = new Card(8, 2, 4, '♠');
    this.c9 = new Card(9, 3, 5, '♣');
    this.c10 = new Card(10, 5, 6, '♥');
    this.e1 = new Card('e');

    this.c02 = new Card(10, 0, 1, '♣');
    this.c03 = new Card(3, 1, 1, '♣');

    this.k1 = new Card(13, 1, 0, '♣');


    // decks
    this.deck1 = new ArrayList<Card>(); // has 1 2 3 4 5
    deck1.add(c1);
    deck1.add(c2);
    deck1.add(c3);
    deck1.add(c4);
    deck1.add(c5);
    this.deck2 = new ArrayList<Card>(); // has 6 7 8 9 10
    deck2.add(c6);
    deck2.add(c7);
    deck2.add(c8);
    deck2.add(c9);
    deck2.add(c10);
    this.deck3 = new ArrayList<Card>(); // the one with all of them
    deck3.add(c1);
    deck3.add(c2);
    deck3.add(c3);
    deck3.add(c4);
    deck3.add(c5);
    deck3.add(c6);
    deck3.add(c7);
    deck3.add(c8);
    deck3.add(c9);
    deck3.add(c10);

    this.deck4 = new ArrayList<Card>();
    deck4.add(c1);
    this.deck5 = new ArrayList<Card>();
    deck5.add(c02);
    deck5.add(c5);


    // empty deck
    this.deckee = new ArrayList<Card>();
    deckee.add(e1);
    deckee.add(e1);

    //deck with a king
    this.deckKing = new ArrayList<Card>();
    deckKing.add(k1);

    //deck with one empty space
    this.emptyDeck = new ArrayList<Card>();
    emptyDeck.add(e1);


    // deck 2 with out the 10 at the end
    this.deckw010 = new ArrayList<Card>();
    deckw010.add(c6);
    deckw010.add(c7);
    deckw010.add(c8);
    deckw010.add(c9);
    deckw010.add(e1);


    //pyramid 1-- the one with three
    this.pyramid = new ArrayList<ArrayList<Card>>();
    pyramid.add(deck4);
    pyramid.add(deck5);

    //p1 with the bottom 2 removed
    this.pyramid01 = new ArrayList<ArrayList<Card>>();
    pyramid01.add(deck4);
    pyramid01.add(deckee);

    // pyramid with king
    this.pyramidk = new ArrayList<ArrayList<Card>>();
    pyramidk.add(deckKing);
    pyramidk.add(deck5);

    //pyramid with king removed
    this.pyramidwok = new ArrayList<ArrayList<Card>>();
    pyramidwok.add(emptyDeck);
    pyramidwok.add(deck5);

    // pryamid for test remove using draw: still using an array of array
    this.pyramidd2d1 = new ArrayList<ArrayList<Card>>();
    pyramidd2d1.add(deck2);
    pyramidd2d1.add(deck1);


    // game state
    this.test1 = new BasicPyramidSolitaire();
    test1.startGame(test1.getDeck(), false, 5, 2);

    this.test2 = new BasicPyramidSolitaire();
    test2.startGame(test2.getDeck(), false, 6, 1);


    // game has not started

    this.test3 = new BasicPyramidSolitaire();

    // for the illegal argument exception for start game
    this.test4 = new BasicPyramidSolitaire();

    this.test5 = new BasicPyramidSolitaire();

  }

  /**
   * test for ToString for a card.
   */

  @Test
  public void testCardString() {
    assertEquals("A♣", c1.toString());
  }

  /**
   * test for ToString for an empty card.
   */

  @Test
  public void testCardString01() {
    assertEquals("  ", new Card('e').toString());
  }

  /**
   * validates it is a deck bc it has 52 elements another test below it testing
   * random cards to make sure the are in the deck instead of testing every
   * single element.
   */

  @Test
  public void testGetDeck() {
    assertEquals(this.test1.getDeck().size(), 52);
  }

  @Test
  public void testgetDeck1() {
    assertEquals(test1.getDeck().contains(c1), true);

  }

  @Test
  public void testgetDeck2() {
    assertEquals(test2.getDeck().contains(c2), true);
  }

  /**
   * testing the exceptions for the remove method.
   */


  @Test(expected = IllegalArgumentException.class)
  public void testRemoveEx01() {
    this.test2.remove(10, 1);
  }


  /**
   * ensuring the start game method works by checking that its fields have been
   * instantiated correctly. for example being shuffled when the shouldShuffle
   * field is true.
   */

  @Test
  public void testStartGame() {
    this.test2.startGame(test2.getDeck(), true, 3, 2);
    assertEquals(test2.getNumRows(), 3);
  }

  @Test
  public void testStartGame01() {
    this.test1.startGame(test1.getDeck(), true, 2, 2);
    Collections.shuffle(test2.getDeck(), new Random());
    assertEquals(test1.getDeck(), test2.getDeck());
  }

  @Test
  public void testStartGame001() {
    ArrayList draws = new ArrayList<>();
    draws.add(new Card('♣', "4"));
    draws.add(new Card('♠', "5"));

    this.test1.startGame(test1.getDeck(), false, 5, 2);
    assertEquals(draws, test1.getDrawCards());
    this.test1.startGame(test1.getDeck(), false, 5, 2);
    assertEquals(draws, test1.getDrawCards());
  }


  @Test(expected = IllegalArgumentException.class)
  public void testStartgameExc() {
    List l1 = test4.getDeck();
    l1.set(0, c2);
    test4.startGame(l1, true, 3, 4);
  }

  // testing with invalid numRows and numDraw

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameExc() {
    test2.startGame(test2.getDeck(), false, -10, -10);
  }


  @Test(expected = IllegalArgumentException.class)
  public void testStartGameExec() {
    test2.startGame(test2.getDeck(), false, 10, -10);
  }

  //test for startGame with a null deck

  //test for startGame with a null deck

  @Test(expected = IllegalArgumentException.class)
  public void testStartgame01() {
    test2.startGame(null, false, 10, 2);
  }

  //test for startGame with a deck that is larger than 52

  @Test(expected = IllegalArgumentException.class)
  public void teststartGame02() {
    List l1 = test5.getDeck();
    l1.add(c3);
    test5.startGame(l1, true, 2, 4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void teststartGame03() {
    List l1 = test5.getDeck();
    l1.add(c3);
    test5.startGame(l1, true, 22, 4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void teststartGame04() {
    List l1 = test5.getDeck();
    l1.add(c3);
    test5.startGame(l1, true, 3, 0);
  }


  /**
   * Testing GetCardAt, as well as its exceptions.
   */

  @Test
  public void testGetCardAt() {
    this.test1.getCardAt(0, 0);
    assertEquals(this.test2.getCardAt(0, 0), new Card('♠', "A"));
  }

  //    @Test
  //    public void testGetCardAt01() {
  //      this.test1.getCardAt(1, 1);
  //      assertEquals(this.test1.getCardAt(1, 1), new Card('♥', "A"));
  //    }
  //
  //  @Test
  //  public void testGetCardAt02() {
  //   this.test1.getCardAt(4, 2);
  //   assertEquals(this.test1.getCardAt(4,2), new Card('♠', "4" ));
  //  }
  //  @Test
  //  public void testGetCardAt03() {
  //    this.test1.getCardAt(3, 2);
  //    assertEquals(this.test1.getCardAt(4,2), new Card('♠', "3" ));
  //  }


  @Test(expected = IllegalArgumentException.class)
  public void testGetCardExc01() {
    this.test2.getCardAt(19, 30);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetCardExc02() {
    this.test1.getCardAt(10, 10);

  }

  /**
   * Test for Get Rows.
   */

  @Test
  public void testgetRows() {
    assertEquals(test2.getNumRows(), 6);
  }

  @Test
  public void testgetRow2() {
    assertEquals(test3.getNumRows(), -1);
  }

  @Test
  public void testgetRows01() {
    assertEquals(this.test1.getNumRows(), 5);
  }

  /**
   * Testing to see if the correct score is produced.
   */

  @Test
  public void testGetScore() {
    assertEquals(test2.getScore(), 66);
  }

  @Test
  public void testGetScore1() {
    assertEquals(test1.getScore(), 36);
  }

  @Test
  public void testisGameOver() {
    assertEquals(test1.isGameOver(), false);
  }

  @Test
  public void testisGameOver1() {
    assertEquals(test2.isGameOver(), false);
  }


  @Test
  public void testisGameOver2() {
    assertEquals(test5.isGameOver(), false);
  }


  //test for get Num draw, return -1 if the game has not started

  @Test
  public void testgetNumDraw() {
    assertEquals(this.test3.getNumDraw(), -1);
  }

  @Test
  public void testgetNumDraw01() {
    assertEquals(this.test2.getNumDraw(), 1);
  }

  @Test
  // test for remove
  public void testRemove() {
    test1.remove(4, 0, 4, 1);
    assertEquals(this.test1.getCardAt(4, 0), null);
    assertEquals(this.test1.getCardAt(4, 1), null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveExc() {
    test1.remove(0, 0, 1, 0);
  }

  @Test
  // test for remove
  public void testRemove01() {
    test1.remove(4, 0);
    assertEquals(this.test1.getCardAt(4, 0), null);
  }

  //test for discard draw
  @Test
  public void testdiscardDraw() {
    test1.discardDraw(0);
    assertEquals(this.test1.getDrawCards().get(0), this.test1.getDrawCards().get(0));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDD() {
    test1.discardDraw(10);
  }

}









