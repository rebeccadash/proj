import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.util.List;

import cs3500.pyramidsolitaire.controller.PyramidSolitaireController;
import cs3500.pyramidsolitaire.controller.PyramidSolitaireTextualController;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.model.hw04.TriPeaksPyramidSolitaire;

import static junit.framework.TestCase.assertEquals;

/**
 * An interaction with the user consists of some input to send the program and
 * some output to expect.  We represent it as an object that takes in two
 * StringBuilders and produces the intended effects on them.
 */

public class TriTest {
  interface Interaction {
    void apply(StringBuilder in, StringBuilder out);
  }

  /**
   * Represents the printing of a sequence of lines to output.
   */
  static class PrintInteraction implements ControllerTest.Interaction {
    String[] lines;

    PrintInteraction(String... lines) {
      this.lines = lines;
    }

    public void apply(StringBuilder in, StringBuilder out) {
      for (String line : lines) {
        out.append(line).append("\n");
      }
    }
  }

  /**
   * Represents a user providing the program with  an input.
   */
  static class InputInteraction implements ControllerTest.Interaction {
    String input;

    InputInteraction(String input) {
      this.input = input;
    }

    public void apply(StringBuilder in, StringBuilder out) {
      in.append(input);
    }
  }

  void testRun(PyramidSolitaireModel model, List deck,
               boolean shuffle, int numRows, int numDraw,
               ControllerTest.Interaction... interactions)
          throws IOException {
    StringBuilder fakeUserInput = new StringBuilder();
    StringBuilder expectedOutput = new StringBuilder();


    for (ControllerTest.Interaction interaction : interactions) {
      interaction.apply(fakeUserInput, expectedOutput);
    }

    StringReader input = new StringReader(fakeUserInput.toString());
    StringBuilder actualOutput = new StringBuilder();

    PyramidSolitaireController controller =
            new PyramidSolitaireTextualController(input, actualOutput);
    controller.playGame(model, deck, shuffle, numRows, numDraw);

    assertEquals(expectedOutput.toString(), actualOutput.toString());
  }

  TriPeaksPyramidSolitaire model2 = new TriPeaksPyramidSolitaire();

  // test for discarding a card from the drawpile
  @Test
  public void testRun1() throws IOException {

    testRun(model2, model2.getDeck(), false, 4, 3,
            new ControllerTest.InputInteraction("dd 1\n"),
            new ControllerTest.PrintInteraction("      A♠      A♦      A♥\n" +
                    "    A♣  2♠  2♦  2♥  2♣  3♠\n" +
                    "  3♦  3♥  3♣  4♠  4♦  4♥  4♣\n" +
                    "5♠  5♦  5♥  5♣  6♠  6♦  6♥  6♣\n" +
                    "Draw: 7♠, 7♦, 7♥\n" +
                    "Score: 84\n" +
                    "      A♠      A♦      A♥\n" +
                    "    A♣  2♠  2♦  2♥  2♣  3♠\n" +
                    "  3♦  3♥  3♣  4♠  4♦  4♥  4♣\n" +
                    "5♠  5♦  5♥  5♣  6♠  6♦  6♥  6♣\n" +
                    "Draw: 7♣, 7♦, 7♥\n" +
                    "Score: 84"
            ));
  }

  // test for removing a single card when it cant be removed
  @Test
  public void testRun2() throws IOException {
    testRun(model2, model2.getDeck(), false, 4, 3,
            new ControllerTest.InputInteraction("rm1 4 1\n"),
            new ControllerTest.PrintInteraction("      A♠      A♦      A♥\n" +
                    "    A♣  2♠  2♦  2♥  2♣  3♠\n" +
                    "  3♦  3♥  3♣  4♠  4♦  4♥  4♣\n" +
                    "5♠  5♦  5♥  5♣  6♠  6♦  6♥  6♣\n" +
                    "Draw: 7♠, 7♦, 7♥\n" +
                    "Score: 84\n" +
                    "Invalid command. Play again Cannot remove Card\n" +
                    "      A♠      A♦      A♥\n" +
                    "    A♣  2♠  2♦  2♥  2♣  3♠\n" +
                    "  3♦  3♥  3♣  4♠  4♦  4♥  4♣\n" +
                    "5♠  5♦  5♥  5♣  6♠  6♦  6♥  6♣\n" +
                    "Draw: 7♠, 7♦, 7♥\n" +
                    "Score: 84"));

  }

  // test for removing one card
  @Test
  public void testRun3() throws IOException {
    testRun(model2, model2.getDeck(), true, 4, 3,
            new ControllerTest.InputInteraction("rm1 4 5\n"),
            new ControllerTest.PrintInteraction(
                    "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174\n" +
                            "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥      Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 161"));
  }

  // test for discarding invalid draw
  @Test
  public void testRun4() throws IOException {
    testRun(model2, model2.getDeck(), false, 4, 3,
            new ControllerTest.InputInteraction("dd 10\n"),
            new ControllerTest.PrintInteraction("      A♠      A♦      A♥\n" +
                    "    A♣  2♠  2♦  2♥  2♣  3♠\n" +
                    "  3♦  3♥  3♣  4♠  4♦  4♥  4♣\n" +
                    "5♠  5♦  5♥  5♣  6♠  6♦  6♥  6♣\n" +
                    "Draw: 7♠, 7♦, 7♥\n" +
                    "Score: 84\n" +
                    "Invalid command. Play again draw index is not there\n" +
                    "      A♠      A♦      A♥\n" +
                    "    A♣  2♠  2♦  2♥  2♣  3♠\n" +
                    "  3♦  3♥  3♣  4♠  4♦  4♥  4♣\n" +
                    "5♠  5♦  5♥  5♣  6♠  6♦  6♥  6♣\n" +
                    "Draw: 7♠, 7♦, 7♥\n" +
                    "Score: 84"));

  }

  // test for removing 2 cards
  @Test
  public void testRun5() throws IOException {
    testRun(model2, model2.getDeck(), true, 4, 3,
              new ControllerTest.InputInteraction("rm2 4 2 4 4\n"),
              new ControllerTest.PrintInteraction(
                      "      A♣      4♥      K♥\n" +
                              "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                              "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                              "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                              "Draw: A♠, 5♣, Q♦\n" +
                              "Score: 174\n" +
                              "      A♣      4♥      K♥\n" +
                              "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                              "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                              "5♠      4♦      K♦  Q♦  3♣  5♣\n" +
                              "Draw: A♠, 5♣, Q♦\n" +
                              "Score: 161"));
  }

  //test for removing 2 cards but its not valid
  @Test
  public void testRun6() throws IOException {
    testRun(model2, model2.getDeck(), true, 4, 3,
            new ControllerTest.InputInteraction("rm2 1 2 4 4\n"),
            new ControllerTest.PrintInteraction(
                    "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174\n" +
                            "Invalid command. Play again Move cannot be made\n" +
                            "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174"));
  }

  // test for removing with draw
  @Test
  public void testRun7() throws IOException {
    testRun(model2, model2.getDeck(), true, 4, 3,
            new ControllerTest.InputInteraction("rmwd 1 4 2\n"),
            new ControllerTest.PrintInteraction(
                    "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174\n" +
                            "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠      4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: 7♦, 5♣, Q♦\n" +
                            "Score: 162"));
  }

  // test for remove using draw but the move cannot be made
  @Test
  public void testRun8() throws IOException {
    testRun(model2, model2.getDeck(), true, 4, 3,
            new ControllerTest.InputInteraction("rmwd 1 2 2\n"),
            new ControllerTest.PrintInteraction(
                    "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174\n" +
                            "Invalid command. Play again cannot remove card if it is not open\n" +
                            "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174"));
  }

  //test for game quit on the row
  @Test
  public void testRun9() throws IOException {
    testRun(model2, model2.getDeck(), true, 4, 3,
            new ControllerTest.InputInteraction("rm1 q 2\n"),
            new ControllerTest.PrintInteraction(
                    "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174\n" +
                            "Game quit!\n" +
                            "State of game when quit: \n" +
                            "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174"));
  }

  //test game quit on the card
  @Test
  public void testRun10() throws IOException {
    testRun(model2, model2.getDeck(), true, 4, 3,
            new ControllerTest.InputInteraction("rm1 2 q\n"),
            new ControllerTest.PrintInteraction(
                    "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174\n" +
                            "Game quit!\n" +
                            "State of game when quit: \n" +
                            "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174"));
  }

  //bogus inputs
  @Test
  public void testRun11() throws IOException {
    testRun(model2, model2.getDeck(), true, 4, 3,
            new ControllerTest.InputInteraction("rm1 adf 4 5\n"),
            new ControllerTest.PrintInteraction(
                    "      A♣      4♥      K♥\n" +
                            "    J♠  10♠ 10♣ 8♥  8♥  5♦\n" +
                            "  2♥  3♥  8♦  3♦  K♥  7♠  K♣\n" +
                            "5♠  Q♠  4♦  A♥  K♦  Q♦  3♣  5♣\n" +
                            "Draw: A♠, 5♣, Q♦\n" +
                            "Score: 174\n" +
                            "Invalid command. Play again"));
  }

  //testing for invalid deck
  @Test (expected = IllegalStateException.class)
  public void testRun12() throws IOException {
    List deck = model2.getDeck();
    deck.set(0, new Card('♠', "J"));
    testRun(model2, deck, true, 4,3);
  }



}
