import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.util.List;

import cs3500.pyramidsolitaire.controller.PyramidSolitaireController;
import cs3500.pyramidsolitaire.controller.PyramidSolitaireTextualController;
import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;

import static junit.framework.TestCase.assertEquals;

/**
 * An interaction with the user consists of some input to send the program and
 * some output to expect.  We represent it as an object that takes in two
 * StringBuilders and produces the intended effects on them.
 */

public class ControllerTest {
  interface Interaction {
    void apply(StringBuilder in, StringBuilder out);
  }

  /**
   * Represents the printing of a sequence of lines to output.
   */
  static class PrintInteraction implements Interaction {
    String[] lines;

    PrintInteraction(String... lines) {
      this.lines = lines;
    }

    public void apply(StringBuilder in, StringBuilder out) {
      for (String line : lines) {
        out.append(line).append("\n");
      }
    }
  }

  /**
   * Represents a user providing the program with  an input.
   */
  static class InputInteraction implements Interaction {
    String input;

    InputInteraction(String input) {
      this.input = input;
    }

    public void apply(StringBuilder in, StringBuilder out) {
      in.append(input);
    }
  }

  void testRun(PyramidSolitaireModel model, List deck,
               boolean shuffle, int numRows, int numDraw, Interaction... interactions)
          throws IOException {
    StringBuilder fakeUserInput = new StringBuilder();
    StringBuilder expectedOutput = new StringBuilder();


    for (Interaction interaction : interactions) {
      interaction.apply(fakeUserInput, expectedOutput);
    }

    StringReader input = new StringReader(fakeUserInput.toString());
    StringBuilder actualOutput = new StringBuilder();

    PyramidSolitaireController controller =
            new PyramidSolitaireTextualController(input, actualOutput);
    controller.playGame(model, deck, shuffle, numRows, numDraw);

    assertEquals(expectedOutput.toString(), actualOutput.toString());
  }

  BasicPyramidSolitaire model1 = new BasicPyramidSolitaire();


  // test for discarding a card from the drawpile
  @Test
  public void testRun1() throws IOException {

    testRun(model1, model1.getDeck(), true, 4, 3,
            new InputInteraction("dd 1\n"),
            new PrintInteraction("      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣  3♦  6♣  2♦\n" +
                    "Draw: 9♥, 5♥, K♠\n" +
                    "Score: 75\n" +
                    "      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠  4♣  J♣\n" +
                    "K♣  3♦  6♣  2♦\n" +
                    "Draw: 3♥, 5♥, K♠\n" +
                    "Score: 75"
            ));
  }

  // test for removing a single card
  @Test
  public void testRun2() throws IOException {
    testRun(model1, model1.getDeck(), true, 4, 3,
            new InputInteraction("rm1 4 1\n"),
            new PrintInteraction("      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣  3♦  6♣  2♦\n" +
                    "Draw: 9♥, 5♥, K♠\n" +
                    "Score: 75\n" +
                    "      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "    3♦  6♣  2♦\n" +
                    "Draw: 9♥, 5♥, K♠\n" +
                    "Score: 62"
            ));
  }

  // test to try to remove 2 cards that do not add up to 13
  @Test
  public void testRun01() throws IOException {
    testRun(model1, model1.getDeck(), true, 4, 3,
            new InputInteraction("rm2 4 2 3 1\n"),
            new PrintInteraction("      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣  3♦  6♣  2♦\n" +
                    "Draw: 9♥, 5♥, K♠\n" +
                    "Score: 75\n" +
                    "Invalid command. Play again Move cannot be made\n" +
                    "      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣  3♦  6♣  2♦\n" +
                    "Draw: 9♥, 5♥, K♠\n" +
                    "Score: 75"));
  }


  // testing the exception of trying to remove from an invalid draw index
  @Test
  public void testRun02() throws IOException {
    testRun(model1, model1.getDeck(), false, 4, 3,
            new InputInteraction("rmwd 5 1 2"),
            new PrintInteraction("      A♠\n" +
                    "    A♦  A♥\n" +
                    "  A♣  2♠  2♦\n" +
                    "2♥  2♣  3♠  3♦\n" +
                    "Draw: 3♥, 3♣, 4♠\n" +
                    "Score: 18\n" +
                    "Invalid command. Play again No card at this index\n" +
                    "      A♠\n" +
                    "    A♦  A♥\n" +
                    "  A♣  2♠  2♦\n" +
                    "2♥  2♣  3♠  3♦\n" +
                    "Draw: 3♥, 3♣, 4♠\n" +
                    "Score: 18"));
  }

  // This was supposed to be testing removing two cards until I realized its not
  // physically possible with this deck
  // but this does test dd, rm1, and rmwd
  @Test
  public void testRun03() throws IOException {
    testRun(model1, model1.getDeck(), true, 4, 3,
            new InputInteraction("dd 1\n"),
            new PrintInteraction("      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣  3♦  6♣  2♦\n" +
                    "Draw: 9♥, 5♥, K♠\n" +
                    "Score: 75\n" +
                    "      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣  3♦  6♣  2♦\n" +
                    "Draw: 3♥, 5♥, K♠\n" +
                    "Score: 75"),
            new InputInteraction("dd 1\n"),
            new PrintInteraction("      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣  3♦  6♣  2♦\n" +
                    "Draw: 8♣, 5♥, K♠\n" +
                    "Score: 75"),
            new InputInteraction("dd 1\n"),
            new PrintInteraction("      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣  3♦  6♣  2♦\n" +
                    "Draw: 8♥, 5♥, K♠\n" +
                    "Score: 75"), new InputInteraction("dd 1\n"),
            new PrintInteraction("      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣  3♦  6♣  2♦\n" +
                    "Draw: 10♣, 5♥, K♠\n" +
                    "Score: 75"),
            new InputInteraction("rmwd 1 4 2\n"),
            new PrintInteraction("      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣      6♣  2♦\n" +
                    "Draw: J♦, 5♥, K♠\n" +
                    "Score: 72"),
            new InputInteraction("rmwd 1 4 4\n"),
            new PrintInteraction("      Q♣\n" +
                    "    7♠  7♦\n" +
                    "  10♠ 4♣  J♣\n" +
                    "K♣      6♣    \n" +
                    "Draw: J♥, 5♥, K♠\n" +
                    "Score: 70"),
            new InputInteraction("dd 1\n"),
            new PrintInteraction(
                    "      Q♣\n" +
                            "    7♠  7♦\n" +
                            "  10♠ 4♣  J♣\n" +
                            "K♣      6♣    \n" +
                            "Draw: J♥, 5♥, K♠\n" +
                            "Score: 70"),

            new InputInteraction("rm1 4 1"),
            new PrintInteraction(
                    "      Q♣\n" +
                            "    7♠  7♦\n" +
                            "  10♠ 4♣  J♣\n" +
                            "        6♣    \n" +
                            "Draw: J♥, 5♥, K♠\n" +
                            "Score: 57"));

  }


  //test for removing two cards from the pile
  @Test
  public void testRun04() throws IOException {
    testRun(model1, model1.getDeck(), true, 7, 3,
            new InputInteraction("rm2 7 1 7 2 \n"),
            new PrintInteraction("            Q♣\n" +
                    "          7♠  7♦\n" +
                    "        10♠  4♣  J♣\n" +
                    "      K♣  3♦  6♣  2♦\n" +
                    "    9♥  5♥  K♠  3♥  8♣\n" +
                    "  8♥  10♣  J♦  J♥  6♠  10♦\n" +
                    "Q♥  A♦  4♠  2♣  4♦  10♥  J♠\n" +
                    "Draw: 5♣, 4♥, 2♥\n" +
                    "Score: 213\n" +
                    "            Q♣\n" +
                    "          7♠  7♦\n" +
                    "        10♠  4♣  J♣\n" +
                    "      K♣  3♦  6♣  2♦\n" +
                    "    9♥  5♥  K♠  3♥  8♣\n" +
                    "  8♥  10♣  J♦  J♥  6♠  10♦\n" +
                    "        4♠  2♣  4♦  10♥  J♠\n" +
                    "Draw: 5♣, 4♥, 2♥\n" +
                    "Score: 200"));
  }

  // testing that a game will not start without a valid deck
  @Test(expected = IllegalArgumentException.class)
  public void testRun05() throws IOException {
    testRun(null, model1.getDeck(), true, 7, 3,
            new InputInteraction("rm2 7 1 7 2 \n"));
  }

  // testing errors
  @Test
  public void testRun06() throws IOException {
    testRun(model1, model1.getDeck(), false, 7, 1,
            new InputInteraction("rm1 1 1"),
            new PrintInteraction("            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112\n" +
                    "Invalid command. Play again Cannot remove card\n" +
                    "            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112"));
  }

  //testting error with removing with a draw card
  @Test
  public void testRun07() throws IOException {
    testRun(model1, model1.getDeck(), false, 7, 1,
            new InputInteraction("rmwd 1 7 1"),
            new PrintInteraction("            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112\n" +
                    "Invalid command. Play again cannot remove cards\n"
                    +
                    "            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112"));
  }

  // testing for when the readable is null
  @Test(expected = IllegalArgumentException.class)
  public void testRun08() throws IOException {
    testRun(null, model1.getDeck(), true, 7, 3,
            new InputInteraction(null));
  }
  //  // throw ISE if appendable is null
  //  @Test(expected = IllegalStateException.class)
  //  public void testRun008() throws IOException {
  //    testRun(null, model1.getDeck(), true, 7, 3,
  //            new InputInteraction("dd 1 \n"),
  //            new PrintInteraction(null));
  //  }

  // test for when the given params are no valid
  @Test(expected = IllegalArgumentException.class)
  public void testRun09() throws IOException {
    testRun(null, model1.getDeck(), true, 10, 3,
            new InputInteraction("dd 1 \n"));
  }

  // test for when the given params are no valid
  @Test(expected = IllegalArgumentException.class)
  public void testRun10() throws IOException {
    testRun(null, model1.getDeck(), true, 6, 90,
            new InputInteraction("dd 1 \n"));
  }

  // test for when the draw card for discard draw is out of bounds
  @Test
  public void testRun11() throws IOException {
    testRun(model1, model1.getDeck(), false, 7, 1,
            new InputInteraction("dd 7"),
            new PrintInteraction("            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112\n" +
                    "Invalid command. Play again draw index is not there\n"
                    +
                    "            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112"));
  }


  // test for quitting the game on the row
  @Test
  public void testRun12() throws IOException {
    testRun(model1, model1.getDeck(), false, 7, 1,
            new InputInteraction("rm1 q 2"),
            new PrintInteraction("            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112\n" +
                    "Game quit!\n" +
                    "State of game when quit: \n" +
                    "            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112"));

  }

  // test for quitting the game on the card
  @Test
  public void testRun102() throws IOException {
    testRun(model1, model1.getDeck(), false, 7, 1,
            new InputInteraction("rm1 2 Q"),
            new PrintInteraction("            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112\n" +
                    "Game quit!\n" +
                    "State of game when quit: \n" +
                    "            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112"));

  }


  //test for bogus inputs
  @Test
  public void testRun13() throws IOException {
    testRun(model1, model1.getDeck(), false, 7, 1,
            new InputInteraction("rm1 2 akljfhafh"),
            new PrintInteraction("            A♠\n" +
                    "          A♦  A♥\n" +
                    "        A♣  2♠  2♦\n" +
                    "      2♥  2♣  3♠  3♦\n" +
                    "    3♥  3♣  4♠  4♦  4♥\n" +
                    "  4♣  5♠  5♦  5♥  5♣  6♠\n" +
                    "6♦  6♥  6♣  7♠  7♦  7♥  7♣\n" +
                    "Draw: 8♠\n" +
                    "Score: 112\n" +
                    "Invalid command. Play again"));

  }

}






