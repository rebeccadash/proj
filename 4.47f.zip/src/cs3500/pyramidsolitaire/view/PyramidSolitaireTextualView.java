package cs3500.pyramidsolitaire.view;

import java.io.IOException;
import java.util.ArrayList;


import java.util.Objects;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;


/**
 * Class representing the textual view of a game of pyramid solitaire.
 */
public class PyramidSolitaireTextualView<K> implements PyramidSolitaireView {
  private PyramidSolitaireModel<?> model;
  private ArrayList<ArrayList<K>> pyramid;

  private char cardType;
  private Appendable ap;

  /**
   * Class representing the textual view of a game of pyramid solitaire.
   */
  public PyramidSolitaireTextualView(PyramidSolitaireModel<?> model) {
    this.model = model;
    this.pyramid = new ArrayList<ArrayList<K>>();
  }


  public PyramidSolitaireTextualView(PyramidSolitaireModel<?> model, Appendable ap) {
    this.model = model;
    this.ap = ap;
  }


  boolean isAllEmpty() {
    int i = 0;
    Object card;
    ArrayList<K> row = new ArrayList<K>();
    while (i < pyramid.size()) {
      while (i < row.size()) {
        if (cardType == ('e')) {
          i++;
        }
      }
    }
    return true;
  }


  @Override
  public boolean equals(Object o) {
    if (o instanceof PyramidSolitaireTextualView) {
      pyramid.toString().equals(o.toString());
    }
    return true;
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.model, this.pyramid);
  }


  // for null cards
  private String nullCards(int row, int card) {
    if (model.getCardAt(row, card) == null) {
      return "  ";
    } else {
      return model.getCardAt(row, card).toString();
    }
  }

  // for null cards in the draw pile
  private String nullDraws(int drawInd) {
    if (model.getDrawCards().get(drawInd) == null) {
      return "  ";
    } else {
      return model.getDrawCards().get(drawInd).toString();
    }
  }

  /**
   * making the textual view of the game.
   *
   * @return the textual view of the game.
   */

  @Override
  public String toString() {
    if (model.getNumRows() == -1) {
      return "";
    }
    else if (model.getScore() == 0 && model.getNumRows() != -1) {
      return "You win!";
    }
    String strPyr = "";
    String draws = "";
    for (int i = 0; i < model.getNumRows(); i++) {

      for (int k = 0; k < model.getNumRows() - (i + 1); k++) {
        strPyr += "  ";

      }

      String row = "";
      for (int j = 0; j < model.getRowWidth(i); j++) {
        if (j == model.getRowWidth(i) - 1) {
          row += nullCards(i, j);
        } else {
          row += nullCards(i, j) + addSpacing(nullCards(i, j));
        }
      }
      strPyr += row.stripTrailing();
      if (i < model.getNumRows() - 1) {
        strPyr += "\n";
      }
    }
    for (int i = 0; i < model.getDrawCards().size(); i++) {
      if (i == model.getDrawCards().size() - 1) {
        draws += nullDraws(i);
      } else {
        draws += nullDraws(i) + ", "; // take away comma if empty
      }
    }
    return strPyr + "\n" + "Draw: " + draws;
  }

  // if its a 10
  protected String addSpacing(String card) {
    String space = "";
    if (card.length() == 3) {
      space = " ";
    } else {
      space = "  ";
    }
    return space;
  }



  // add try catch for IOException
  @Override
  public void render() throws IOException {
    try {
      ap.append(toString());
    } catch (IOException e) {
      ap.append("could not render image");
    }
  }
}

