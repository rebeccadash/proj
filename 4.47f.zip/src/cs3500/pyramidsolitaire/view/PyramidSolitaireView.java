package cs3500.pyramidsolitaire.view;


import java.io.IOException;

/**
 * Interface representing the view.
 */
public interface PyramidSolitaireView {
  /**
   * Renders a model in some manner.
   * @throws IOException if the rendering fails for some reason.
   */

  void render() throws IOException;

}
