package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;

/**
 * returns the appropriate model from what the user inputted.
 */
public class PyramidSolitaireCreator {

  /**
   * represents the different kinds of game types using enum.
   */
  public enum GameType {
    BASIC("basic"), RELAXED("relaxed"), TRIPEAKS("tripeaks");


    private GameType(String str) {
      String value;
      value = str;
    }
  }

  /**
   * returns the correct model based on what was entered.
   * @param type a game type.
   * @return the correct model.
   */
  public static PyramidSolitaireModel create(GameType type) {
    switch (type) {
      case BASIC:
        return new BasicPyramidSolitaire();
      case RELAXED:
        return new RelaxedPyramidSolitaire();
      case TRIPEAKS:
        return new TriPeaksPyramidSolitaire();
      default:
        throw new IllegalArgumentException("given type not available");
    }
  }

}
