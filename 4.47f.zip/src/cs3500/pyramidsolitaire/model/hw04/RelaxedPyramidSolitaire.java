package cs3500.pyramidsolitaire.model.hw04;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import cs3500.pyramidsolitaire.model.hw02.Card;

/**
 * Class representing the relaxed game. The rules are the same as basic except
 * for that if a card is only covered by a card that sums to 13 with the prior,
 * you can remove both cards. Also in this version draw cards are allowed to be
 * 0.
 */
public class RelaxedPyramidSolitaire extends AbstractModel {


  @Override
  public void startGame(List deck, boolean shouldShuffle, int numRows, int numDraw) {
    this.pyramid = new ArrayList<ArrayList<Card>>();
    this.stockVis = new ArrayList<Card>();
    this.drawPile = new ArrayList<Card>();
    this.deck = new ArrayList<Card>();


    if (numRows < 1 || numDraw < 0 || numRows > 9) {
      throw new IllegalArgumentException("Invalid Inputs");
    }

    this.numRows = numRows;
    this.numDraw = numDraw;
    int count = 0;
    Random r = new Random(0);

    if (deck == null) {
      throw new IllegalArgumentException("Cannot pass in a null deck");
    }
    List<Card> copydeck = new ArrayList<>(deck);
    // List<Card> copydraws = new ArrayList<>(getDrawCards());

    if (deck.size() != 52) {
      throw new IllegalArgumentException("Deck is not valid");
    }
    //to check if there are duplicate cards in a deck
    if (isDuplicates(deck)) {
      throw new IllegalArgumentException("Duplicate cards do not exist in a valid deck");
    }

    if (shouldShuffle) {
      Collections.shuffle(copydeck, r);
    }
    // for loop to add cards to the pyramid until the size of the pyramid is done
    for (int i = 0; i < numRows; i++) {
      ArrayList<Card> rowCards = new ArrayList<Card>();
      for (int j = 0; j < this.getRowWidth(i); j++) {
        rowCards.add(copydeck.get(count));
        count++;
      }
      pyramid.add(rowCards);
    }


    // another for loop to add cards to the draw pile
    for (int j = (pyrCards(pyramid)).size(); j < 52; j++) {

      drawPile.add(copydeck.get(j));
    }

    if (numDraw == 0) {
      stockVis = new ArrayList<>();
    }
    // add cards to the stock pile
    if (drawPile.size() >= numDraw) {
      stockVis = new ArrayList<>();
      for (int i = 0; i < numDraw; i++) {
        stockVis.add(drawPile.get(i));
      }

      drawPile.removeAll(stockVis);


    } else {
      throw new IllegalArgumentException("Invalid Number of Draws, must be "
              + drawPile.size() + " cards or less.");
    }
    if (numDraw > 52 - pyrCards(pyramid).size()) {
      throw new IllegalArgumentException("cannot use this draw index");
    }
    gameStart = true;
  }

  //change so that if the last two cards left are adding up to 13 you can remove them
  @Override
  public void remove(int row1, int card1, int row2, int card2) throws IllegalStateException {
    Card c1 = getCardAt(row1, card1);
    Card c2 = getCardAt(row2, card2);
    if (!gameStart) {
      throw new IllegalStateException("game has not started");
    }


    if (row1 >= getNumRows() || row2 >= getNumRows()) {
      throw new IllegalArgumentException("card is not in the pyramid");
    }
    if (isOpen(row1, card1) && isOpen(row2, card2)) {
      if (getCardVal(c1) + getCardVal(c2) != 13) {
        throw new IllegalArgumentException("cannot remove a pair that dont add to 13");
      }
    }
    //normal
    if (isOpen(row1, card1) && isOpen(row2, card2)) {
      if (getCardVal(c1) + getCardVal(c2) == 13) {
        this.pyramid.get(row1).set(card1, null);
        this.pyramid.get(row2).set(card2, null);
      }
    }

    // the other way aka going from the second jack to the two
    else {
      if (isOpen(row1, card1)) {
        if (this.pyramid.get(row2 + 1).get(card2 + 1) != null &&
                this.pyramid.get(row2 + 1).get(card2) == null) {
          if (row1 == row2 + 1 && card1 == card2 + 1) {
            if (getCardVal(c1) + getCardVal(c2) == 13) {
              this.pyramid.get(row1).set(card1, null);
              this.pyramid.get(row2).set(card2, null);
            } else {
              throw new IllegalArgumentException("cannot remove a pair that dont add to 13");
            }
          } else {
            throw new IllegalArgumentException("Cards are not open");
          }
        } else if (this.pyramid.get(row2 + 1).get(card2) != null &&
                this.pyramid.get(row2 + 1).get(card2 + 1) == null) {
          if (row1 == row2 + 1 && card1 == card2) {
            if (getCardVal(c1) + getCardVal(c2) == 13) {
              this.pyramid.get(row1).set(card1, null);
              this.pyramid.get(row2).set(card2, null);
            } else {
              throw new IllegalArgumentException("cannot remove a pair that dont add to 13");
            }
          } else {
            throw new IllegalArgumentException("Cards are not open");
          }
        } else if (this.pyramid.get(row2 + 1).get(card2) != null &&
                this.pyramid.get(row2 + 1).get(card2 + 1) != null) {
          throw new IllegalArgumentException("Cards are not open");
        } else {
          if (getCardVal(c1) + getCardVal(c2) == 13) {
            this.pyramid.get(row1).set(card1, null);
            this.pyramid.get(row2).set(card2, null);
          } else {
            throw new IllegalArgumentException("cannot remove a pair that dont add to 13");
          }
        }
      } else if (isOpen(row2, card2)) {
        if (this.pyramid.get(row1 + 1).get(card1 + 1) != null &&
                this.pyramid.get(row1 + 1).get(card1) == null) {
          if (row2 == row1 + 1 && card2 == card1 + 1) {
            if (getCardVal(c1) + getCardVal(c2) == 13) {
              this.pyramid.get(row1).set(card1, null);
              this.pyramid.get(row2).set(card2, null);
            } else {
              throw new IllegalArgumentException("cannot remove a pair that dont add to 13");
            }
          }
        } else if (this.pyramid.get(row1 + 1).get(card1) != null &&
                this.pyramid.get(row1 + 1).get(card1 + 1) == null) {
          if (row2 == row1 + 1 && card2 == card1) {
            if (getCardVal(c1) + getCardVal(c2) == 13) {
              this.pyramid.get(row1).set(card1, null);
              this.pyramid.get(row2).set(card2, null);
            } else {
              throw new IllegalArgumentException("cannot remove a pair that dont add to 13");
            }
          }
        } else if (this.pyramid.get(row1 + 1).get(card1) != null &&
                this.pyramid.get(row1 + 1).get(card1 + 1) != null) {
          throw new IllegalArgumentException("Cards are not open");
        } else {
          if (getCardVal(c1) + getCardVal(c2) == 13) {
            this.pyramid.get(row1).set(card1, null);
            this.pyramid.get(row2).set(card2, null);
          } else {
            throw new IllegalArgumentException("cannot remove a pair that dont add to 13");
          }
        }
      } else {
        throw new IllegalArgumentException("Cards are not open");
      }
    }
  }

}






