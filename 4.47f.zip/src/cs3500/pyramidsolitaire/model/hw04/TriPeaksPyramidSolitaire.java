package cs3500.pyramidsolitaire.model.hw04;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import cs3500.pyramidsolitaire.model.hw02.Card;

/**
 * Class representing a tripeaks game, the same rules apply to basic but there
 * are much more cards.
 */
public class TriPeaksPyramidSolitaire extends AbstractModel {


  public TriPeaksPyramidSolitaire() {
    super();
  }


  /**
   * Returns a double deck.
   *
   * @return a deck with 2 of each element.
   */
  @Override
  public List getDeck() {
    int i = 0;
    List<Card> copydeck = new ArrayList<Card>(104);
    Card card;
    ArrayList<Character> suits = new ArrayList<Character>(4);
    suits.add('♠');
    suits.add('♦');
    suits.add('♥');
    suits.add('♣');
    ArrayList<String> ranks = new ArrayList<String>(13);
    ranks.add("A");
    ranks.add("2");
    ranks.add("3");
    ranks.add("4");
    ranks.add("5");
    ranks.add("6");
    ranks.add("7");
    ranks.add("8");
    ranks.add("9");
    ranks.add("10");
    ranks.add("J");
    ranks.add("Q");
    ranks.add("K");

    for (int rank = 0; rank < 13; rank++) {
      for (int suit = 0; suit < 4; suit++) {
        card = new Card(suits.get(suit), ranks.get(rank));
        copydeck.add(card);
      }
    }
    copydeck.addAll(copydeck);
    return copydeck;
  }


  // building big mama
  @Override
  public void startGame(List deck, boolean shouldShuffle, int numRows, int numDraw) {
    this.pyramid = new ArrayList<ArrayList<Card>>();
    this.stockVis = new ArrayList<Card>();
    this.drawPile = new ArrayList<Card>();
    this.deck = new ArrayList<Card>();
    int numTopRows = (int) Math.floor(numRows / 2);
    int countCinPeak = 0;
    // the number of cards in the last row before it gets merged
    int numPeaks = 3;
    int rowSize = numTopRows * numPeaks;

    if (numRows < 1 || numDraw < 0 || numRows > 9) {
      throw new IllegalArgumentException("Invalid Inputs");
    }

    this.numRows = numRows;
    this.numDraw = numDraw;
    int count = 0;
    Random r = new Random(0);

    if (deck == null) {
      throw new IllegalArgumentException("Cannot pass in a null deck");
    }
    List<Card> copydeck = new ArrayList<>(deck);
    // List<Card> copydraws = new ArrayList<>(getDrawCards());

    if (deck.size() != 104) {
      throw new IllegalArgumentException("Deck is not valid");
    }

    if (!isValid(deck)) {
      throw new IllegalArgumentException("deck not valid");
    }

    if (shouldShuffle) {
      Collections.shuffle(copydeck, r);
    }

    if (numRows == 1) {
      ArrayList<Card> rowCards = new ArrayList<Card>();
      rowCards.add(copydeck.get(0));
      pyramid.add(rowCards);
    } else {
      // for loop to add cards to the pyramid until the size of the pyramid is done
      count = 0;
      for (int i = numRows; i < numRows * 2; i++) {
        ArrayList<Card> rowCards = new ArrayList<Card>();
        if (i < (numRows + numTopRows) - 1) {
          for (int p = 0; p < numPeaks; p++) {
            countCinPeak = 0;
            for (int cinp = 0; cinp <= i - numRows; cinp++) {
              rowCards.add((Card) copydeck.get(count));
              count++;
              countCinPeak++;
            }
            if (p < numPeaks - 1) {
              for (int e = 0; e < (double) (i - countCinPeak * numPeaks) / 2; e++) {
                rowCards.add(null);
              }
            }
          }
        } else {
          // after the peaks
          if (isEven(numRows)) {
            for (int col = 0; col <= i; col++) {
              rowCards.add((Card) copydeck.get(count));
              count++;
            }
          } else {
            for (int col = 0; col < i; col++) {
              rowCards.add((Card) copydeck.get(count));
              count++;
            }
          }

        }
        pyramid.add(rowCards);
      }
    }
    // for standard size should be 64
    // another for loop to add cards to the draw pile
    for (int j = (pyrCards(pyramid)).size(); j < 104; j++) {
      drawPile.add(copydeck.get(j));
    }

    // add cards to the stock pile
    if (drawPile.size() >= numDraw) {
      stockVis = new ArrayList<>();
      for (int i = 0; i < numDraw; i++) {
        stockVis.add(drawPile.get(i));
      }
      drawPile.removeAll(stockVis);


    } else {
      throw new IllegalArgumentException("Invalid Number of Draws, must be "
              + drawPile.size() + " cards or less.");
    }
    if (numDraw > 104 - pyrCards(pyramid).size()) {
      throw new IllegalArgumentException("cannot use this draw index");
    }


    gameStart = true;
  }

  @Override
  public int getRowWidth(int row) {
    if (isEven(numRows)) {
      return row + getNumRows() + 1;
    } else {
      return row + getNumRows();
    }
  }

  // helper for whether or not a number is even
  private boolean isEven(int num) {
    return (num % 2 == 0);
  }


  // validate for triPeaks
  private boolean isValid(List deck) {
    int count = 0;
    for (int i = 0; i < deck.size(); i++) {
      for (int j = i + 1; j < deck.size(); j++) {
        if (deck.get(i).equals(deck.get(j))) {
          count++;
        }
      }
    }
    return  (count == 52);
  }

}

