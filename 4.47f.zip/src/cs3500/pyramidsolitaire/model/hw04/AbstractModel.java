package cs3500.pyramidsolitaire.model.hw04;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;

/**
 * Abstract class containing all of the general use methods before they get over
 * written.
 */
public class AbstractModel implements PyramidSolitaireModel {
  protected ArrayList<ArrayList<Card>> pyramid;
  protected ArrayList<Card> stockVis;
  private int cardVal;
  private char cardType;
  private int cardsUsed;
  protected List<Card> deck;
  boolean gameStart = false;
  int i;
  int numDraw;
  protected int numRows;
  List<Card> cards;
  protected ArrayList<Card> drawPile;
  List flatPyr = new ArrayList();

  /**
   * Constructor for the abstract model.
   */
  public AbstractModel() {
    this.pyramid = new ArrayList<ArrayList<Card>>();
    this.stockVis = new ArrayList<Card>();
    this.drawPile = new ArrayList<Card>();
    this.deck = new ArrayList<Card>();

  }

  // this get deck works for basic and relaxed
  @Override
  public List getDeck() {
    List<Card> copydeck = new ArrayList<Card>(52);
    Card card;
    ArrayList<Character> suits = new ArrayList<Character>(4);
    suits.add('♠');
    suits.add('♦');
    suits.add('♥');
    suits.add('♣');
    ArrayList<String> ranks = new ArrayList<String>(13);
    ranks.add("A");
    ranks.add("2");
    ranks.add("3");
    ranks.add("4");
    ranks.add("5");
    ranks.add("6");
    ranks.add("7");
    ranks.add("8");
    ranks.add("9");
    ranks.add("10");
    ranks.add("J");
    ranks.add("Q");
    ranks.add("K");
    for (int rank = 0; rank < 13; rank++) {
      for (int suit = 0; suit < 4; suit++) {
        card = new Card(suits.get(suit), ranks.get(rank));
        copydeck.add(card);
      }
    }
    return copydeck;
  }


  @Override
  public void startGame(List deck, boolean shouldShuffle, int numRows, int numDraw) {
    this.pyramid = new ArrayList<ArrayList<Card>>();
    this.stockVis = new ArrayList<Card>();
    this.drawPile = new ArrayList<Card>();
    this.deck = new ArrayList<Card>();


    if (numRows < 1 || numDraw < 1 || numRows > 9) {
      throw new IllegalArgumentException("Invalid Inputs");
    }

    this.numRows = numRows;
    this.numDraw = numDraw;
    int count = 0;
    Random r = new Random(0);

    if (deck == null) {
      throw new IllegalArgumentException("Cannot pass in a null deck");
    }
    List<Card> copydeck = new ArrayList<>(deck);
    // List<Card> copydraws = new ArrayList<>(getDrawCards());

    if (deck.size() != 52) {
      throw new IllegalArgumentException("Deck is not valid");
    }
    //to check if there are duplicate cards in a deck
    if (isDuplicates(deck)) {
      throw new IllegalArgumentException("Duplicate cards do not exist in a valid deck");
    }

    if (shouldShuffle) {
      Collections.shuffle(copydeck, r);
    }
    // for loop to add cards to the pyramid until the size of the pyramid is done
    for (int i = 0; i < numRows; i++) {
      ArrayList<Card> rowCards = new ArrayList<Card>();
      for (int j = 0; j < this.getRowWidth(i); j++) {
        rowCards.add(copydeck.get(count));
        count++;
      }
      pyramid.add(rowCards);
    }


    // another for loop to add cards to the draw pile
    for (int j = (pyrCards(pyramid)).size(); j < 52; j++) {

      drawPile.add(copydeck.get(j));
    }


    // add cards to the stock pile
    if (drawPile.size() >= numDraw) {
      stockVis = new ArrayList<>();
      for (int i = 0; i < numDraw; i++) {
        stockVis.add(drawPile.get(i));
      }
      drawPile.removeAll(stockVis);


    } else {
      throw new IllegalArgumentException("Invalid Number of Draws, must be "
              + drawPile.size() + " cards or less.");
    }
    if (numDraw > 52 - pyrCards(pyramid).size()) {
      throw new IllegalArgumentException("cannot use this draw index");
    }
    gameStart = true;
  }

  //   // test to see if there are duplicates in a deck of cards
  protected boolean isDuplicates(List deck) {
    for (int i = 0; i < deck.size(); i++) {
      for (int j = i + 1; j < deck.size(); j++) {
        if (deck.get(i).equals(deck.get(j))) {
          return true;
        }
      }
    }
    return false;
  }

  // helper   /**
  //   * See if all cards are empty.used for game over
  //   */
  protected boolean isAllEmpty() {
    int i = 0;
    ArrayList<Card> row = new ArrayList<Card>();
    ArrayList<ArrayList<Card>> allCards = new ArrayList<ArrayList<Card>>();
    while (i < allCards.size()) {
      while (i < row.size()) {
        char cardType = 0;
        if (cardType == ('e')) {
          i++;
        }
      }
    }
    return true;
  }

  // is Open
  // is Open: returns whether or not you can remove a card
  protected boolean isOpen(int row, int card) {

    if (row == getNumRows() - 1) {
      return true;
    }
    if (row < 0) {
      return false;
    }
    return (this.pyramid.get(row + 1).get(card) == null &&
            this.pyramid.get(row + 1).get(card + 1) == null);
  }


  @Override
  public void remove(int row1, int card1, int row2, int card2) throws IllegalStateException {
    Card c1 = getCardAt(row1, card1);
    Card c2 = getCardAt(row2, card2);
    if (!gameStart) {
      throw new IllegalStateException("game has not started");
    }
    if (row1 >= getNumRows() || row2 >= getNumRows()) {
      throw new IllegalArgumentException("card is not in the pyramid");
    }
    if (isOpen(row1, card1) && isOpen(row2, card2)) {
      if (getCardVal(c1) + getCardVal(c2) != 13) {
        throw new IllegalArgumentException("cannot remove a pair that dont add to 13");
      }
    }

    if (isOpen(row1, card1) && isOpen(row2, card2)) {
      if (getCardVal(c1) + getCardVal(c2) == 13) {
        this.pyramid.get(row1).set(card1, null);
        this.pyramid.get(row2).set(card2, null);
      }
    } else {
      throw new IllegalArgumentException("Move cannot be made");
    }
  }

  @Override
  public void remove(int row, int card) throws IllegalStateException {
    if (!gameStart) {
      throw new IllegalStateException("game has not started");
    }
    if (row >= getNumRows()) {
      throw new IllegalArgumentException("cannot remove card out of bounds");
    }


    if (isOpen(row, card)) {
      if (getCardVal(getCardAt(row, card)) != 13) {

        throw new IllegalArgumentException("Cannot remove Card");
      }
    }
    if (isOpen(row, card)) {
      if (getCardVal(getCardAt(row, card)) == 13) {
        this.pyramid.get(row).set(card, null);
      }
    } else {
      throw new IllegalArgumentException("Cannot remove card");
    }
  }


  @Override
  public void removeUsingDraw(int drawIndex, int row, int card) throws IllegalStateException {

    if (isGameOver()) {
      throw new IllegalArgumentException("cannot play anymore");
    }
    if (drawIndex > getNumDraw()) {
      throw new IllegalArgumentException("No card at this index");
    }
    if (!gameStart) {
      throw new IllegalStateException("game has not started");
    }
    if (getDrawCards().get(drawIndex) == (null)) {
      throw new IllegalArgumentException("Cannot remove an empty card");
    }
    if (!isOpen(row, card)) {
      throw new IllegalArgumentException("cannot remove card if it is not open");
    }

    if (getCardVal(getDrawCards().get(drawIndex)) + (getCardVal(getCardAt(row, card))) == 13) {
      if (drawPile.size() == 0) {
        this.pyramid.get(row).set(card, null);
        stockVis.set(drawIndex, null);

      } else {

        this.pyramid.get(row).set(card, null);
        stockVis.set(drawIndex, drawPile.get(0));
        drawPile.removeAll(stockVis);


      }
    } else if ((getCardVal(getDrawCards().get(drawIndex)) +
            (getCardVal(getCardAt(row, card))) != 13)) {
      throw new IllegalArgumentException("cannot remove cards");
    }
  }


  @Override
  public void discardDraw(int drawIndex) throws IllegalStateException {

    //drawPile.removeAll(stockVis);
    int stockSize = stockVis.size();

    if (drawIndex > getNumDraw()) {
      throw new IllegalArgumentException("draw index is not there");
    }

    if (!gameStart) {
      throw new IllegalStateException("game has not started");
    }

    if (drawPile.size() == 0) {
      stockVis.set(drawIndex, null);
      // stockVis.remove(drawIndex);
    } else {
      Card s1 = drawPile.remove(0);
      stockVis.set(drawIndex, s1);
      // stockVis.remove(drawIndex);
    }

  }


  @Override
  public int getNumRows() {
    if (!gameStart) {
      return -1;
    } else {
      return this.numRows;
    }
  }

  @Override
  public int getNumDraw() {
    if (!gameStart) {
      return -1;
    } else {
      return numDraw;
    }
  }


  @Override
  public int getRowWidth(int row) {
    return row + 1;
  }

  // over when there are no moves left , nothing to remove together
  // no remove with draw
  // draw pile and stock pile are both empty
  @Override
  public boolean isGameOver() throws IllegalStateException {
    if (!gameStart) {
      return false;
    }
    if (getScore() == 0) {
      return true;
    }
    return (areStockEmpty() && isNoMovesLeft(allOpens()));
  }


  // are all the stocks empty
  protected boolean areStockEmpty() {
    for (int i = 0; i < getNumDraw(); i++) {
      if (getCardVal(getDrawCards().get(i)) != 0) {
        return false;
      }
    }
    return true;
  }

  protected ArrayList<Card> allOpens() {
    ArrayList<Card> opens = new ArrayList<Card>();
    int i = 0;
    int j = 0;
    for (int row = 0; row < getNumRows(); row++) {
      for (int card = 0; card < getRowWidth(row); card++) {
        if (isOpen(row, card)) {
          opens.add(getCardAt(row, card));
        }
      }
    }
    return opens;
  }

  protected boolean isNoMovesLeft(ArrayList<Card> opens) {
    for (int i = 0; i < opens.size(); i++) {
      for (int j = i + 1; j < opens.size(); j++) {
        if (((getCardVal(opens.get(i)) + getCardVal(opens.get(j))) == 13)) {
          return false;
        }
      }
    }
    return true;
  }

  @Override
  public int getScore() throws IllegalStateException {
    if (!gameStart) {
      throw new IllegalStateException("game has not started");
    }
    int score = 0;
    for (int k = 0; k < numRows; k++) {
      for (int i = 0; i < getRowWidth(k); i++) {
        try {
          score += getCardVal(getCardAt(k, i));
        } catch (IllegalArgumentException e) {
          throw new IllegalArgumentException(e);
        }

      }
    }
    return score;
  }

  @Override
  public Card getCardAt(int row, int card) throws IllegalStateException {
    if (!gameStart) {
      throw new IllegalStateException("game has not started");
    }
    if (row > getNumRows() - 1 || card > getRowWidth(row) - 1) {
      throw new IllegalArgumentException("card is out of bounds");
    }
    if (row < 0 || card < 0) {
      throw new IllegalArgumentException("cannot acccess this card ");
    }

    return pyramid.get(row).get(card);
  }


  @Override
  public List<Card> getDrawCards() throws IllegalStateException {

    if (gameStart) {
      return new ArrayList<>(stockVis);
    } else {
      throw new IllegalStateException("Game has not started");
    }
  }


  // returns a list of all the cards in the pyramid
  protected List<Card> pyrCards(ArrayList<ArrayList<Card>> pyramid) {
    flatPyr = new ArrayList();
    for (ArrayList<Card> list : pyramid) {
      for (Card c : list) {
        try {
          if (getCardVal(c) != 0) {
            flatPyr.add(c);
          }
        } catch (Exception e) {
          // doesnt need an exception bc it is just not adding null cards (val 0)
        }
      }
    }
    return flatPyr;
  }


  // used in remove (if there are no cards left keep the card as empty)
  private int cardsRemain() {
    return deck.size() - cardsUsed;
  }

  //
  // returns the type
  private char getType(Card card) {

    if (card == null) {
      return 'e';
    } else if (card.toString().indexOf('♥') != -1) {
      return '♥';
    } else if (card.toString().indexOf('♠') != -1) {
      return '♠';
    } else if (card.toString().indexOf('♣') != -1) {
      return '♣';
    } else if (card.toString().indexOf('♦') != -1) {
      return '♦';
    } else {
      throw new IllegalArgumentException("could not find card type");
    }
  }

  // returns the value
  protected int getCardVal(Object o) {
    if (o == null) {
      return 0;
    }
    if (o.toString().contains("A")) {
      return 1;
    }
    if (o.toString().contains("2")) {
      return 2;
    }
    if (o.toString().contains("3")) {
      return 3;
    }
    if (o.toString().contains("4")) {
      return 4;
    }
    if (o.toString().contains("5")) {
      return 5;
    }
    if (o.toString().contains("6")) {
      return 6;
    }
    if (o.toString().contains("7")) {
      return 7;
    }
    if (o.toString().contains("8")) {
      return 8;
    }
    if (o.toString().contains("9")) {
      return 9;
    }
    if (o.toString().contains("10")) {
      return 10;
    }
    if (o.toString().contains("J")) {
      return 11;
    }
    if (o.toString().contains("Q")) {
      return 12;
    }
    if (o.toString().contains("K")) {
      return 13;
    } else {
      throw new IllegalArgumentException("Could not find card value");
    }
  }

  private String getCardValasString(Card card) {

    if (card.toString().contains("A")) {
      return "A";
    }
    if (card.toString().contains("2")) {
      return "2";
    }
    if (card.toString().contains("3")) {
      return "3";
    }
    if (card.toString().contains("4")) {
      return "4";
    }
    if (card.toString().contains("5")) {
      return "5";
    }
    if (card.toString().contains("6")) {
      return "6";
    }
    if (card.toString().contains("7")) {
      return "7";
    }
    if (card.toString().contains("8")) {
      return "8";
    }
    if (card.toString().contains("9")) {
      return "9";
    }
    if (card.toString().contains("10")) {
      return "10";
    }
    if (card.toString().contains("J")) {
      return "J";
    }
    if (card.toString().contains("Q")) {
      return "Q";
    }
    if (card.toString().contains("K")) {
      return "K";
    }
    if (card == null) {
      return " ";
    }
    return "";

  }


}
