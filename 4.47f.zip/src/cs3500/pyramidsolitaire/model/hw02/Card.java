package cs3500.pyramidsolitaire.model.hw02;

import java.util.Objects;


/**
 * Card class.
 */
public class Card {
  private int index;
  private int value;
  private char type;
  private char suit;
  private String val;

  private boolean isOpen;


  // change the suits to enum
  // value should be between 1 and 13


  /**
   * Card class with value, suit, and its x y position.
   */
  public Card(int value, int xPos, int yPos, char type) {
    this.value = value;
    this.type = type;
    this.index = index;
    this.type = type;
  }

  public Card(char type) {

    this.type = type;
  }


  /**
   * Card class with just the suit and the value.
   */
  public Card(char suit, String val) {
    this.suit = suit;
    this.val = val;
  }

  /**
   * Card class.
   */
  public Card(int value) {
    this.value = value;
  }

  // are two cards == to 13?
  private boolean is13(Card c) {
    return (this.value + c.value == 13);
  }

  private boolean isEmpty() {
    return (this.type == ('e'));
  }

  int getIndex() {
    return this.index;
  }


  /**
   * to String ovveride.
   *
   * @return card as a string
   */
  @Override
  public String toString() {
    if (this.type == 'e') {
      return "  ";
    } else {
      return this.val + this.suit;
    }

  }


  // equals for a card.
  @Override
  public boolean equals(Object o) {
    return (o instanceof Card && ((Card) o).val == this.val && ((Card) o).suit == this.suit);

  }

  @Override
  public int hashCode() {
    return Objects.hash(this.type, this.value);
  }
}

