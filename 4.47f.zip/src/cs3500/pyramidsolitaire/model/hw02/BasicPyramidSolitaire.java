package cs3500.pyramidsolitaire.model.hw02;

import cs3500.pyramidsolitaire.model.hw04.AbstractModel;

/**
 * Rules: You can only remove cards if their combined value is 13. you can
 * remove a King by itself. you can only remove cards if they are "open" meaning
 * their bottom corners are not touching any other cards. A player wins by
 * clearing the board and obtaining a score of 0.
 */

public class BasicPyramidSolitaire extends AbstractModel {


  /**
   * Empty Constructor for the builder of the game.
   */

  public BasicPyramidSolitaire() {
    super();
  }


}

