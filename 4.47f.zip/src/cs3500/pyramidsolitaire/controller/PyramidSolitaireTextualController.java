package cs3500.pyramidsolitaire.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;

/**
 * Represents the controller for the game.
 *
 * @param <K> the game.
 */
public class PyramidSolitaireTextualController<K> implements PyramidSolitaireController {
  private Readable rd;
  private Appendable ap;
  private PyramidSolitaireModel<K> model;
  private PyramidSolitaireTextualView view;

  private Scanner in;

  /**
   * Represents the controller for the game.
   */
  public PyramidSolitaireTextualController(Readable rd, Appendable ap)
          throws IllegalArgumentException {

    if (rd == null || ap == null) {
      throw new IllegalArgumentException("values cannot be null");
    }
    this.rd = rd;
    this.ap = ap;
    this.view = view;
    in = new Scanner(this.rd);
  }


  @Override
  public <K> void playGame(PyramidSolitaireModel<K> model, List<K> deck,
                           boolean shuffle, int numRows, int numDraw)
          throws IllegalArgumentException, IllegalStateException {


    PyramidSolitaireTextualView view = new PyramidSolitaireTextualView(model, ap);
    if (model == null) {
      throw new IllegalArgumentException("Null model not accepted");
    }

    try {
      model.startGame(deck, shuffle, numRows, numDraw);
    } catch (IllegalArgumentException e) {
      throw new IllegalStateException("invalid inputs");
    }

    String nextMove;
    boolean noQuit = true;


    //initial gameState and score
    this.apTryCatch(view.toString() + "\nScore: " + model.getScore() + "\n");


    String next;

    // while (in.hasNext()) {
    while (noQuit && in.hasNext()) {
      if (model.isGameOver()) {
        this.apTryCatch(view.toString());
        break;
      }
      ArrayList<String> inputAr = new ArrayList<String>();

      if (in.hasNext()) {
        nextMove = in.next();
        inputAr.add(nextMove);
      }

      if (inputAr.get(0).equals("Q") || inputAr.get(0).equals("q")) {
        this.apTryCatch("Game quit!\nState of game when quit: \n"
                + view.toString() + "\nScore: " + model.getScore());
        noQuit = false;
        break;
      }

      if (inputAr.get(0).equals("dd")) {
        try {
          inputAr.add(in.next());
          if (ifQ(inputAr)) {
            this.apTryCatch("Game quit!\nState of game when quit: \n"
                    + view.toString() + "\nScore: " + model.getScore());
            break;
          }
          tryInput(inputAr, model);
        } catch (IllegalArgumentException e) {
          this.apTryCatch("Invalid command. Play again " + e.getMessage() + "\n");
        }
      } else if (inputAr.get(0).equals("rm1")) {
        try {
          inputAr.add(in.next());
          if (ifQ(inputAr)) {
            this.apTryCatch("Game quit!\nState of game when quit: \n"
                    + view.toString() + "\nScore: " + model.getScore() + "\n");
            break;
          }
          inputAr.add(in.next());
          if (ifQ(inputAr)) {
            this.apTryCatch("Game quit!\nState of game when quit: \n"
                    + view.toString() + "\nScore: " + model.getScore() + "\n");
            break;
          }
          tryInput(inputAr, model);

        } catch (IllegalArgumentException e) {
          this.apTryCatch("Invalid command. Play again " + e.getMessage() + "\n");
        }
      } else if (inputAr.get(0).equals("rm2")) {
        try {
          inputAr.add(in.next());
          if (ifQ(inputAr)) {
            this.apTryCatch("Game quit!\nState of game when quit: \n"
                    + view.toString() + "\nScore: " + model.getScore() + "\n");
            break;
          }
          inputAr.add(in.next());
          if (ifQ(inputAr)) {
            this.apTryCatch("Game quit!\nState of game when quit: \n"
                    + view.toString() + "\nScore: " + model.getScore() + "\n");
            break;
          }
          inputAr.add(in.next());
          if (ifQ(inputAr)) {
            this.apTryCatch("Game quit!\nState of game when quit: \n"
                    + view.toString() + "\nScore: " + model.getScore() + "\n");
            break;
          }
          inputAr.add(in.next());

          tryInput(inputAr, model);

        } catch (IllegalArgumentException e) {
          this.apTryCatch("Invalid command. Play again " + e.getMessage() + "\n");
        }
      } else if (inputAr.get(0).equals("rmwd")) {
        try {
          inputAr.add(in.next());
          if (ifQ(inputAr)) {
            this.apTryCatch("Game quit!\nState of game when quit: \n"
                    + view.toString() + "\nScore: " + model.getScore() + "\n");
            break;
          }
          inputAr.add(in.next());
          if (ifQ(inputAr)) {
            this.apTryCatch("Game quit!\nState of game when quit: \n"
                    + view.toString() + "\nScore: " + model.getScore() + "\n");
            break;
          }
          inputAr.add(in.next());
          tryInput(inputAr, model);

        } catch (IllegalArgumentException e) {
          this.apTryCatch("Invalid command. Play again " + e.getMessage() + "\n");
        }
      }
      // if q or Q
      if (ifQ(inputAr)) {
        this.apTryCatch("Game quit!\nState of game when quit: \n"
                + view.toString() + "\nScore: " + model.getScore() + "\n");
        noQuit = false;
        break;
      }

      if (ifAllFalse(inputAr, model) && !in.hasNext()) {
        this.apTryCatch("Invalid command. Play again\n");
        //add a new method here to distribute errors as they should be
      }

      if (!ifAllFalse(inputAr, model)) {
        this.apTryCatch(view.toString() + "\nScore: " + model.getScore() + "\n");
      }
      if (!noQuit) {
        if (model.isGameOver()) {
          if (model.getScore() == 0) {
            this.apTryCatch(view.toString());
          } else {
            this.apTryCatch("Game over. " + "Score: " + model.getScore()
            );
          }
        }
      }
      if (model.isGameOver()) {
        if (model.getScore() == 0) {
          this.apTryCatch(view.toString());
        } else {
          this.apTryCatch("Game over. " + "Score: " + model.getScore()
          );
        }
      }
    }
  }


  // try a move
  // have to figure out a way to access the row and card number for this
  private void tryInput(ArrayList<String> input, PyramidSolitaireModel model) {

    PyramidSolitaireTextualView view = new PyramidSolitaireTextualView(model);
    if (isValidrm1(input)) {
      model.remove(Integer.parseInt(input.get(1)) - 1, Integer.parseInt(input.get(2)) - 1);
    } else if (isValidrm2(input)) {
      model.remove(Integer.parseInt(input.get(1)) - 1, Integer.parseInt(input.get(2)) - 1,
              Integer.parseInt(input.get(3)) - 1, Integer.parseInt(input.get(4)) - 1);
    } else if (isValidRwD(input)) {
      model.removeUsingDraw(Integer.parseInt(input.get(1)) - 1, Integer.parseInt(input.get(2)) - 1,
              Integer.parseInt(input.get(3)) - 1);
    } else if (isValidDD(input)) {
      model.discardDraw(Integer.parseInt(input.get(1)) - 1);
    }

  }

  // throwing exceptions for a valid input
  private boolean ifAllFalse(ArrayList<String> input, PyramidSolitaireModel model) {
    PyramidSolitaireTextualView view = new PyramidSolitaireTextualView(model);
    return ((!isValidrm1(input)) && (!isValidrm2(input)) &&
            (!isValidRwD(input)) && (!isValidDD(input)) && (!ifQ(input)));
  }


  // validate the number of inputs for remove 1
  private boolean isValidrm1(ArrayList<String> input) {
    if (input.size() == 3) {
      return (input.get(0).equals("rm1") && isInteger(input.get(1)) && isInteger(input.get(2)));
    } else {
      return false;
    }
  }

  // validate inputs for remove 2
  private boolean isValidrm2(ArrayList<String> input) {
    if (input.size() == 5) {
      return (input.get(0).equals("rm2") && isInteger(input.get(1)) && isInteger(input.get(2))
              && isInteger(input.get(3)) && isInteger(input.get(4)));
    } else {
      return false;
    }
  }

  //validate inputs for remove w d
  private boolean isValidRwD(ArrayList<String> input) {
    if (input.size() == 4) {
      return (input.get(0).equals("rmwd") && isInteger(input.get(1)) && isInteger(input.get(2))
              && isInteger(input.get(3)));
    } else {
      return false;
    }
  }

  // valid inputs for dd
  private boolean isValidDD(ArrayList<String> input) {
    if (input.size() == 2) {
      return (input.get(0).equals("dd") && isInteger(input.get(1)));
    } else {
      return false;
    }
  }

  // helper
  private boolean isInteger(String str) {
    try {
      Integer.parseInt(str);
      return true;
    } catch (IllegalArgumentException e) {
      return false;
    }
  }

  private boolean ifQ(ArrayList<String> input) {
    for (int i = 0; i < input.size(); i++) {
      if (input.get(i).equals("Q") || input.get(i).equals("q")) {
        return true;
      }
    }
    return false;
  }


  //ap try catch
  private void apTryCatch(String in) {
    try {
      ap.append(in);
    } catch (IOException f) {
      throw new IllegalStateException("error with input");
    }
  }
}
