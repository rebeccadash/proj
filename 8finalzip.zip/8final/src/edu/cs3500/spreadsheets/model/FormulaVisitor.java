package edu.cs3500.spreadsheets.model;

/**
 * A generic formula visitor containing the different visitors for each type of Formula.
 *
 * @param <R> is the generic type the visitor can return
 */
public interface FormulaVisitor<R> {

  R visitValString(ValueString s);

  R visitValBool(ValueBoolean b);

  R visitValNum(ValueNumber n);

  R visitRef(Reference r);

  R visitFunction(Function func);
}
