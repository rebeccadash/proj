package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Read only version of a Worksheet model.
 */
public class ReadOnlyModel implements Worksheet {




  public Worksheet getWs() {
    return ws;
  }

  @Override
  public Value createTriangle(Coord coord) {
    return ws.getWs().createTriangle(coord);
  }

  private Worksheet ws;



  public ReadOnlyModel(Worksheet ws) {
    this.ws = ws;
  }

  @Override
  public Cell getCellAt(Coord coord) {
    return ws.getCellAt(coord);

  }

  @Override
  public ArrayList<Cell> getGroup(Coord coord1, Coord coord2) {

    return ws.getGroup(coord1, coord2);
  }

  @Override
  public void changeContents(Formula contents, Coord coord) {
    // does nothing
  }

  @Override
  public String readContents(Cell c) {
    return c.getRawContents();
  }

  @Override
  public void deleteContents(Coord c) {
    ws.deleteContents(c);
  }

  @Override
  public void setContents(Coord c, Formula contents) {
   //
  }

  @Override
  public Value evalCell(Coord str) {

    return ws.getWs().evalCell(str);
  }


  @Override
  public HashMap<Coord, Cell> getSpreadsheet() {
    return ws.getSpreadsheet();
  }

  @Override
  public WorksheetModel getModel() {
    return null;
  }

  @Override
  public boolean checkForm(String input) {
    if (input.contains("=(")) {
      return (input.contains("SUM") || input.contains("PRODUCT")
              ||
              input.contains("<") || input.contains("BUILDSTORY"));
    }
    return true;
  }



}


