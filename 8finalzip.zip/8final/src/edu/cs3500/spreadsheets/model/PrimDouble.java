package edu.cs3500.spreadsheets.model;

/**
 * Translates a Formula Double into a primitive Double that Java can handle.
 */
public class PrimDouble implements FormulaVisitor<Double> {


  @Override
  public Double visitValString(ValueString s) {
    return 0.0;
  }

  @Override
  public Double visitValBool(ValueBoolean b) {
    return 0.0;
  }

  @Override
  public Double visitValNum(ValueNumber n) {
    return n.numVal;
  }

  @Override
  public Double visitRef(Reference r) {
    throw new IllegalStateException("This isn't a value!");
  }

  @Override
  public Double visitFunction(Function func) {
    throw new IllegalStateException("This isn't a value!");
  }
}
