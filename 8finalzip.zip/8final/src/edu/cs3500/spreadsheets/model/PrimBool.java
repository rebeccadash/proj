package edu.cs3500.spreadsheets.model;

/**
 * Translates a Formula Boolean into a primitive Boolean that Java can handle.
 */
public class PrimBool implements FormulaVisitor<Boolean> {

  @Override
  public Boolean visitValString(ValueString s) {
    return false;
  }

  @Override
  public Boolean visitValBool(ValueBoolean b) {
    return b.boolval;
  }

  @Override
  public Boolean visitValNum(ValueNumber n) {
    return false;
  }

  @Override
  public Boolean visitRef(Reference r) {
    throw new IllegalStateException("Should not be doing this");
  }

  @Override
  public Boolean visitFunction(Function func) {
    throw new IllegalStateException("Should not be doing this");
  }
}
