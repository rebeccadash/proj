package edu.cs3500.spreadsheets.model;

/**
 * Generic Value to represent the value types.
 */
public interface Value extends Formula {

}
