package edu.cs3500.spreadsheets.model;

/**
 * Translates a Formula String into a primitive String that Java can handle.
 */
public class PrimString implements FormulaVisitor<String> {

  @Override
  public String visitValString(ValueString s) {
    return s.strVal;
  }

  @Override
  public String visitValBool(ValueBoolean b) {
    return "";
  }

  @Override
  public String visitValNum(ValueNumber n) {
    return "";
  }

  @Override
  public String visitRef(Reference r) {
    return "";
  }

  @Override
  public String visitFunction(Function func) {
    return "";
  }
}
