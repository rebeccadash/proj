package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * Product function visitor.
 */
public class FormulaVisitorProduct implements WSFunction {
  @Override
  public Value apply(List<Formula> args, Worksheet model) {
    double prod = 1;
    for (Formula a : args) {
      prod *= a.accept(new ProdRef(model)).accept(new PrimDoubleProduct());
    }
    return new ValueNumber(prod);
  }

  @Override
  public String applyToString() {
    return "(=PRODUCT";
  }
}

