package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Represents a Reference.
 */
public class Reference implements Formula {
  private final Coord c1;
  private final Coord c2;

  /**
   * A multi cell reference.
   *
   * @param c1 is the first corner to calculate the area containing cells making up the reference
   * @param c2 is the second corner to calculate the area containing cells making up the reference
   */
  public Reference(Coord c1, Coord c2) {
    if (c1.row > c2.row || c1.col > c2.col) {
      throw new IllegalArgumentException("Corners out of order");
    }
    this.c1 = c1;
    this.c2 = c2;
  }

  /**
   * A single cell Reference.
   *
   * @param c1 is the coordinate of the cell being referenced
   */
  public Reference(Coord c1) {
    this.c1 = c1;
    this.c2 = c1;
  }

  /**
   * Gets the group of coordinates contained within a reference.
   */
  public List<Coord> getGroup() {
    List<Coord> groupOfCoords = new ArrayList<>();
    for (int c = c1.col; c <= c2.col; c++) {
      for (int r = c1.row; r <= c2.row; r++) {
        groupOfCoords.add(new Coord(c, r));
      }
    }
    return groupOfCoords;
  }

  @Override
  public String toString() {
    return getGroup().toString();
  }

  @Override
  public <R> R accept(FormulaVisitor<R> f) {
    return f.visitRef(this);
  }

  @Override
  public String acceptString(OperationsVisitor f) {
    return getGroup().toString();
  }


  @Override
  public Value evaluate(Worksheet model) {
    try {
      if (model.getCellAt(getGroup().get(0)) == null) {
        return new ValueString("");
      }
      if (getGroup().size() == 1) {
        return (model.evalCell(getGroup().get(0)));
      } else {
        return new ValueString(" ");
      }
    }
    catch (StackOverflowError e) {
      return new ValueString("Cyclic Error");
    }
  }

  /**
   * Returns whether the contents of the cell at the given coordinate are cyclic refereces.
   * @param coord is the coordinate
   */
  public boolean isCyclic(Coord coord) {
    Set<Coord> alreadySeen = new HashSet<Coord>();
    // this is if there is no references in the group
    // add each cell in the referenced group
    for (int i = 0; i < this.getGroup().size(); i++) {
      alreadySeen.add(getGroup().get(i));
    }
    if (alreadySeen.contains(coord)) {
      return true;
    }

    // this is for if there are references in the cell
    for (int i = 0; i < this.getGroup().size(); i++) {
      // we dont know how to find this given referne
    }
    return true;
  }
}
