package edu.cs3500.spreadsheets.model;

import java.util.Objects;

/**
 * Represents a String value.
 */
public class ValueString implements Value {
  String strVal;

  public ValueString(String strVal) {
    this.strVal = strVal;
  }

  @Override
  public Value evaluate(Worksheet model) {
    return new ValueString(strVal);
  }

  public String toString() {
    return strVal;
  }


  @Override
  public <R> R accept(FormulaVisitor<R> f) {
    return f.visitValString(this);
  }

  @Override
  public String acceptString(OperationsVisitor f) {
    return strVal;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ValueString that = (ValueString) o;
    return Objects.equals(strVal, that.strVal);
  }

  @Override
  public int hashCode() {
    return Objects.hash(strVal);
  }
}

