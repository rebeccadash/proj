package edu.cs3500.spreadsheets.model;

/**
 * The Reference for build story.
 */
public class BuildRef implements FormulaVisitor<Value> {

  private Worksheet model;

  public BuildRef(Worksheet model) {
    this.model = model;
  }

  @Override
  public Value visitValString(ValueString s) {
    return s;
  }

  @Override
  public Value visitValBool(ValueBoolean b) {
    return new ValueString("");
  }

  @Override
  public Value visitValNum(ValueNumber n) {
    return new ValueString("");
  }

  @Override
  public Value visitRef(Reference r) {
    String story = "";
    for (int i = 0; i < r.getGroup().size(); i++) {
      story += model.evalCell(r.getGroup().get(i)).accept(new PrimString()) + " ";
    }
    return new ValueString(story);
  }


  @Override
  public Value visitFunction(Function func) {
    return func.evaluate(model);
  }
}
