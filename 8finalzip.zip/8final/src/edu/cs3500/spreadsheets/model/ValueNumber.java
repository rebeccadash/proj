package edu.cs3500.spreadsheets.model;

import java.util.Objects;

/**
 * Represents a number value.
 */
public class ValueNumber implements Value {
  double numVal;

  public ValueNumber(double numVal) {
    this.numVal = numVal;
  }

  @Override
  public Value evaluate(Worksheet model) {
    return new ValueNumber(numVal);
  }

  public String toString() {
    return String.valueOf(numVal);
  }

  /**
   * Accepts a visitor to return a Value, a number specifically.
   *
   * @param f   is the visitor
   * @param <R> is the generic type
   */
  @Override
  public <R> R accept(FormulaVisitor<R> f) {
    return f.visitValNum(this);
  }

  @Override
  public String acceptString(OperationsVisitor f) {
    return String.valueOf(numVal);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ValueNumber that = (ValueNumber) o;
    return Double.compare(that.numVal, numVal) == 0;
  }

  @Override
  public int hashCode() {
    return Objects.hash(numVal);
  }
}
