package edu.cs3500.spreadsheets.model;

import java.util.Objects;

import edu.cs3500.spreadsheets.sexp.Sexp;

import static edu.cs3500.spreadsheets.sexp.Parser.parse;

/**
 * Represents a cell in a spreadsheet.
 */
public class Cell implements ICell{
    public Formula contents;

  /**
   * Constructor to build a Cell with its contents.
   *
   * @param contents as a row and col number.
   */
  public Cell(Formula contents) {
    this.contents = contents;
  }

  /**
   * Returns the contents of a cell.
   */
  public Formula getContents() {
    return contents;
  }

  /**
   * Evaluates the contents of a cell in the model of a worksheet.
   *
   * @param model is the model of the worksheet
   */
  public Value eval(Worksheet model) {
    return this.contents.evaluate(model);
  }

  /**
   * Returns the contents of a cell as a string.
   *
   * @return the contents.
   */
  public String getRawContents() {
    return contents.toString();
  }


  @Override
  public boolean equals(Object o) {
    if (!(o instanceof Cell)) {
      return false;
    }
    Cell that = (Cell) o;
    return (this.contents.equals(that.contents));
  }

  @Override
  public int hashCode() {
    return Objects.hash(contents);
  }
}