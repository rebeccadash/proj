package edu.cs3500.spreadsheets.model;

public interface ICell  {

  /**
   * Returns the contents of a cell.
   */
  Formula getContents();


  /**
   * Evaluates the contents of a cell in the model of a worksheet.
   *
   * @param model is the model of the worksheet
   */
   Value eval(Worksheet model);

  /**
   * Returns the contents of a cell as a string.
   *
   * @return the contents.
   */
  String getRawContents();
}
