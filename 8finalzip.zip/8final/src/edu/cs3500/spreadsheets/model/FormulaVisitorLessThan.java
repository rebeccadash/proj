package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * Less than function visitor.
 */
public class FormulaVisitorLessThan implements WSFunction {
  @Override
  public Value apply(List<Formula> args, Worksheet model) {
    if (args.size() > 2) {
      throw new IllegalArgumentException("Cannot compare more than 2 numbers");
    }
    return new ValueBoolean(args.get(0).evaluate(model).accept(new PrimDouble())
            - args.get(1).evaluate(model).accept(new PrimDouble()) < 0);
  }

  @Override
  public String applyToString() {
    return "=(<";
  }
}