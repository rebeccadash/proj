package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * Build story function visitor.
 */
public class FormulaVisitorBuildStory implements WSFunction {
  @Override
  public Value apply(List<Formula> args, Worksheet model) {
    String story = "";
    for (Formula a : args) {
      story += a.accept(new BuildRef(model)).accept(new PrimString());
    }
    return new ValueString(story);
  }

  @Override
  public String applyToString() {
    return "(<";
  }
}