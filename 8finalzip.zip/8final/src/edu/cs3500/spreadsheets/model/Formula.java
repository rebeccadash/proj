package edu.cs3500.spreadsheets.model;

/**
 * A Formula represents a Cell's contents -- can be a Value, Reference, or Function.
 */
public interface Formula {
  /**
   * Evaluates a formula into a single value.
   *
   * @param model is the worksheet model the formula is evaluated in
   */
  Value evaluate(Worksheet model);

  /**
   * Returns the formula as a string.
   */
  String toString();

  /**
   * Accepts a function visitor.
   *
   * @param f is the visitor
   */
  <R> R accept(FormulaVisitor<R> f);

  String  acceptString(OperationsVisitor f);

}
