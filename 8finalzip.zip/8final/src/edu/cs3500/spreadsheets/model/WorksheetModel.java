package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.HashMap;

import edu.cs3500.spreadsheets.sexp.Parser;
import edu.cs3500.spreadsheets.sexp.SexpToFormulaVisitor;

/**
 * A Worksheet (spreadsheet) model.
 */
public class WorksheetModel implements Worksheet {


  private HashMap<Coord, Cell> spreadsheet;


  public WorksheetModel() {
    this.spreadsheet = new HashMap<Coord, Cell>();
  }

  @Override
  public Cell getCellAt(Coord coord) {
    // needs to access the given coord on the spreadsheet
    return spreadsheet.get(coord);
  }

  /**
   * Returns the spreadsheet.
   */
  public HashMap<Coord, Cell> getSpreadsheet() {
    return spreadsheet;
  }


  @Override
  public WorksheetModel getModel() {
    return this;
  }

  // call this when the button is pressed.
  @Override
  public boolean checkForm(String input) {
    if (input.contains("=(")) {
      return (input.contains("SUM") || input.contains("PRODUCT")
              ||
              input.contains("<") || input.contains("BUILDSTORY"));
    }
    return true;
  }

  @Override
  public Worksheet getWs() {
    return this;
  }


  @Override
  public ArrayList<Cell> getGroup(Coord coord1, Coord coord2) {

    ArrayList<Cell> group = new ArrayList<>();

    for (int c = coord1.col; c <= coord2.col; c++) {
      for (int r = coord1.row; r <= coord2.row; r++) {
        group.add(getCellAt(new Coord(c, r)));
      }
    }
    return group;
  }

  @Override
  public void changeContents(Formula formula, Coord coord) {
    spreadsheet.put(coord, new Cell(formula));
  }

  @Override
  public String readContents(Cell c) {
    return c.getRawContents();
  }


  @Override
  public void deleteContents(Coord c) {
    spreadsheet.put(c, new Cell(new ValueString(" ")));
  }

  @Override
  public void setContents(Coord c, Formula formula) {
    spreadsheet.put(c, new Cell(formula));
  }


  @Override
  public Value evalCell(Coord cellCoord) {
    Cell c = getCellAt(new Coord(cellCoord.col, cellCoord.row));
    if (c == null) {
      return new ValueNumber(0);
    }
    //get the contents as something we can evaluate
    // all evaluate on those contents to print out a value
    return c.eval(this);
  }

  @Override
  public Value createTriangle(Coord coord) {
    return (new ValueNumber(((evalCell(coord).accept(new PrimDouble()) + 1)
            * (evalCell(coord).accept(new PrimDouble()))) / 2));

  }

  /**
   * Worksheet builder.
   */

  public static class WorksheetBuilder implements WorksheetReader.WorksheetBuilder<Worksheet> {
    WorksheetModel model;


    public WorksheetBuilder() {
      this.model = new WorksheetModel();
    }

    @Override
    public WorksheetReader.WorksheetBuilder<Worksheet>
        createCell(int col, int row, String contents) {
      if (contents.contains("=")) {
        model.spreadsheet.put(new Coord(col, row),
                new Cell(Parser.parse(contents.substring(1)).accept(new SexpToFormulaVisitor())));
      } else {
        model.spreadsheet.put(new Coord(col, row),
                new Cell(Parser.parse(contents).accept(new SexpToFormulaVisitor())));
      }
      return this;
    }

    @Override
    public Worksheet createWorksheet() {
      return model;
    }
  }
}
