package edu.cs3500.spreadsheets.model;

/**
 * A visitor in order to be able to display the formula as a string without
 * being evaluated.
 */
public interface OperationsVisitor {

  String visitOp(Function f);

}
