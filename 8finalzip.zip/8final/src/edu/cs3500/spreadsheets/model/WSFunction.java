package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * Represents the functions of a worksheet.
 */
public interface WSFunction {
  /**
   * Applies a funtion to a the given list of arguments within the given model,
   * returns the appropriate value.
   * @param args  is the arguments
   * @param model is the model
   */
  Value apply(List<Formula> args, Worksheet model);

  /**
   * Display a formula as a function.
   *
   */
  String applyToString();


}
