package edu.cs3500.spreadsheets.model;

/**
 * The Reference for adding (sum).
 */
public class SumRef implements FormulaVisitor<Value> {

  private Worksheet model;

  public SumRef(Worksheet model) {
    this.model = model;
  }

  @Override
  public Value visitValString(ValueString s) {
    return new ValueNumber(0);
  }

  @Override
  public Value visitValBool(ValueBoolean b) {
    return new ValueNumber(0);
  }

  @Override
  public Value visitValNum(ValueNumber n) {
    return n;
  }

  @Override
  public Value visitRef(Reference r) {
    Double sum = 0.0;
    for (int i = 0; i < r.getGroup().size(); i++) {
      sum += model.evalCell(r.getGroup().get(i)).accept(new PrimDouble());
    }
    return new ValueNumber(sum);
  }

  @Override
  public Value visitFunction(Function func) {
    return func.evaluate(model);
  }
}
