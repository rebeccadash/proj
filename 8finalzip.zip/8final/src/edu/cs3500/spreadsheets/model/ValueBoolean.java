package edu.cs3500.spreadsheets.model;

import java.util.Objects;

/**
 * Represents a boolean value.
 */
public class ValueBoolean implements Value {
  boolean boolval;

  public ValueBoolean(boolean boolval) {
    this.boolval = boolval;
  }


  @Override
  public Value evaluate(Worksheet model) {
    return new ValueBoolean(boolval);
  }


  public String toString() {
    return String.valueOf(boolval);
  }


  @Override
  public <R> R accept(FormulaVisitor<R> f) {
    return f.visitValBool(this);
  }

  @Override
  public String acceptString(OperationsVisitor f) {
    return String.valueOf(boolval);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ValueBoolean that = (ValueBoolean) o;
    return boolval == that.boolval;
  }

  @Override
  public int hashCode() {
    return Objects.hash(boolval);
  }
}
