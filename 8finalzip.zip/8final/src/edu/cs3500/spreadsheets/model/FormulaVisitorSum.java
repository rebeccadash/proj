package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * Sum function visitor.
 */
public class FormulaVisitorSum implements WSFunction {
  @Override
  public Value apply(List<Formula> args, Worksheet model) {
    double sum = 0;
    for (Formula a : args) {
      sum += a.accept(new SumRef(model)).accept(new PrimDouble());
    }
    return new ValueNumber(sum);
  }

  @Override
  public String applyToString() {
    return "=(SUM";
  }
}

