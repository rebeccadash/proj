package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * Represents a Function.
 */
public class Function implements Formula {
  WSFunction f;
  private List<Formula> args;

  /**
   * Constructor to build a Function.
   *
   * @param f    is the operation
   * @param args is the arguments passed in
   */
  public Function(WSFunction f, List<Formula> args) {
    this.f = f;
    this.args = args;
  }

  @Override
  public Value evaluate(Worksheet model) {
    return f.apply(args, model);
  }

  @Override
  public String toString() {
    return f.applyToString() + " " + argsasString() + ")";
  }

  //for loop to put the elements seperatley
  private String argsasString() {
    String argsStr = "";
    for (int i = 0; i < args.size(); i ++) {
      if (args.indexOf(args.get(i)) == args.size()) {
        argsStr += args.get(i);
      }
      else {
        argsStr += args.get(i) + " ";
      }
    }
    return argsStr;
  }


  @Override
  public <R> R accept(FormulaVisitor<R> f) {
    return f.visitFunction(this);
  }



  @Override
  public String acceptString(OperationsVisitor f) {
    return f.visitOp(this);
  }


}
