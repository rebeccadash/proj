package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Represents a Worksheet.
 */
public interface Worksheet {
  /**
   * Return the cell at the given coordinate.
   *
   * @param coord is the coordinate
   */
  Cell getCellAt(Coord coord);

  /**
   * Return the group of cells within the rectangular region defined by the two given coordinates.
   *
   * @param coord1 is the first coordinate
   * @param coord2 is the second coordinate
   */
  ArrayList<Cell> getGroup(Coord coord1, Coord coord2);

  /**
   * Changes the contents of the cell at the given coordinate.
   *
   * @param contents is the new contents
   * @param coord    is the coordinate
   */
  void changeContents(Formula contents, Coord coord);

  /**
   * Reads the contents of the given cell.
   *
   * @param c is the cell
   */
  String readContents(Cell c);

  /**
   * Deletes the contents of the cell at the given coordinate.
   *
   * @param c is the coordinate of the cell
   */
  void deleteContents(Coord c);

  /**
   * Sets the contents of the given cell.
   *
   * @param c        is the cell
   * @param contents is the new contents
   */
  void setContents(Coord c, Formula contents);

  /**
   * Returns the actual evaluated value of the cell at the given coordinate.
   *
   * @param c is the coordinate
   */
  Value evalCell(Coord c);


  /**
   * Getter for the spreadsheet.
   * @return a spredsheet.
   */
  HashMap<Coord, Cell> getSpreadsheet();

  /**
   * getter fot the model itself.
   * @return a model.
   */
  WorksheetModel getModel();

  /**
   * Returns whether or not a string input is a valid formula.
   */
  boolean checkForm(String input);

  /**
   * Returns a cells coordinates based on the contents.
   */

  Worksheet getWs();


  Value createTriangle(Coord coord);
}

