package edu.cs3500.spreadsheets.model;

/**
 * Caroline recommended creating this class for the case because she does not see a cleaner way
 * to do this.
 */

/**
 * Translates a Formula Double into a primitive Double that Java can handle for multiplying.
 */
public class PrimDoubleProduct implements FormulaVisitor<Double> {
  @Override
  public Double visitValString(ValueString s) {
    return 1.0;
  }

  @Override
  public Double visitValBool(ValueBoolean b) {
    return 1.0;
  }

  @Override
  public Double visitValNum(ValueNumber n) {
    return n.accept(new PrimDouble());
  }


  @Override
  public Double visitRef(Reference r) {
    throw new IllegalStateException("This isn't a value!");
  }

  @Override
  public Double visitFunction(Function func) {
    throw new IllegalStateException("This isn't a value!");
  }
}
