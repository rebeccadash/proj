package edu.cs3500.spreadsheets;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import edu.cs3500.spreadsheets.controller.Controller;
import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.ReadOnlyModel;
import edu.cs3500.spreadsheets.model.Value;
import edu.cs3500.spreadsheets.model.Worksheet;
import edu.cs3500.spreadsheets.model.WorksheetModel;
import edu.cs3500.spreadsheets.model.WorksheetReader;
import edu.cs3500.spreadsheets.provider.view.EditViewAdapter;
import edu.cs3500.spreadsheets.provider.view.WorksheetEditableView;
import edu.cs3500.spreadsheets.view.EditView;

import edu.cs3500.spreadsheets.view.GuiView;

import edu.cs3500.spreadsheets.view.IView;
import edu.cs3500.spreadsheets.view.TextualView;

/**
 * The main class for our program.
 */
public class BeyondGood {
  /**
   * The main entry point.
   *
   * @param args any command-line arguments
   */
  public static void main(String[] args) throws IOException {

    WorksheetModel model = new WorksheetModel();
    Controller controller = new Controller(model);
    Worksheet ws;
    Worksheet ws0;
    // if the user inputs a file
    if (args[0].equals("-in")) {
      ws = WorksheetReader.read(new WorksheetModel.WorksheetBuilder(), new FileReader(args[1]));
      // and if the 3rd argument is -gui
      if (args[2].equals("-gui")) {
        // read the input file and display a GUI view of it
        FileReader fileReader = new FileReader(args[1].trim());
        WorksheetModel.WorksheetBuilder wsb = new WorksheetModel.WorksheetBuilder();
        Worksheet works = WorksheetReader.read(wsb, fileReader);
        ReadOnlyModel read = new ReadOnlyModel(works);
        IView view = new GuiView(800, 500, read);
        Controller cont = new Controller(view, read);
        cont.setView(view);
      }
      if (args[2].equals("-edit")) {
        FileReader fileReader = new FileReader(args[1].trim());
        WorksheetModel.WorksheetBuilder wsb = new WorksheetModel.WorksheetBuilder();
        Worksheet works = WorksheetReader.read(wsb, fileReader);
        ReadOnlyModel readOnly = new ReadOnlyModel(works);
        IView viewE = new EditView(800, 500, readOnly);
        Controller cont = new Controller(viewE, works);
        cont.setView(viewE);
      }
    }
    // otherwise create a WorksheetModel
    else {
      ws = new WorksheetModel.WorksheetBuilder().createWorksheet();
    }

    // to render GUI view
    if (args[0].equals("-gui")) {
      IView view = new GuiView(800, 500, new ReadOnlyModel(ws));
      Controller cont = new Controller(view, ws);
      cont.setView(view);
    }
    //renders an empty editable view
    if (args[0].contains("-edit")) {
      IView view = new EditView(800, 400, new ReadOnlyModel(ws));
      Controller cont = new Controller(view, ws);
      cont.setView(view);
    }
    // provider code
    //should just produce a new editable worksheet
    if (args[0].equals("-provider")) {
      IView view = new EditViewAdapter(new WorksheetEditableView());
      Controller cont = new Controller(view, ws);
      cont.setView(view);
    }

    if (args.length == 3) {

      if (args[2].equals("-provider")) {
        FileReader fileReader = new FileReader(args[1].trim());
        WorksheetModel.WorksheetBuilder wsb = new WorksheetModel.WorksheetBuilder();
        Worksheet works = WorksheetReader.read(wsb, fileReader);
        ReadOnlyModel readOnly = new ReadOnlyModel(works);
        IView view = new EditViewAdapter(new WorksheetEditableView());
        Controller cont = new Controller(readOnly);
        cont.setView(view);
      }
      // to evaluate
      if (args[2].equals("-eval")) {
        Value v = ws.evalCell(new Coord(args[2].charAt(0), args[2].charAt(1)));
        System.out.println(v);
      }
      // to save a file

      if (args[2].equals("-save")) {
        FileReader fileReader = new FileReader(args[1]);
        WorksheetModel.WorksheetBuilder wsb = new WorksheetModel.WorksheetBuilder();
        Worksheet works = WorksheetReader.read(wsb, fileReader);
        FileWriter print = new FileWriter(args[3]);
        Appendable out = print;
        new TextualView(works, out).render();
        print.close();
      }
    }
  }
}