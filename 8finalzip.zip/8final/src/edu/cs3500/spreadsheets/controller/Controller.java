package edu.cs3500.spreadsheets.controller;


import java.io.IOException;

import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.Formula;
import edu.cs3500.spreadsheets.model.ReadOnlyModel;
import edu.cs3500.spreadsheets.model.Worksheet;

import edu.cs3500.spreadsheets.sexp.Parser;
import edu.cs3500.spreadsheets.sexp.SexpToFormulaVisitor;
import edu.cs3500.spreadsheets.view.IView;



/**
 * A Class representing the featues of the UI.
 */
public class Controller implements SpreadSheetFeatures {
  private Worksheet ws;
  private IView theView;
  public Controller(Worksheet ws) {
    this.ws = ws;
  }
  public Controller(IView theView) {
    this.theView = theView;
  }

  public Controller(IView theView, Worksheet ws) {
    this.ws = ws;
    this.theView = theView;
  }


  @Override
  public void setView(IView view) throws IOException {
    theView = view;
    view.render();
    view.addFeatures(this);
  }

  @Override
  public void setC(Coord c, String f) {
    ws.setContents(new Coord(c.col - 1, c.row - 1), Parser.parse(f).accept(new SexpToFormulaVisitor()));
    theView.setModel(new ReadOnlyModel(ws));
  }


}
