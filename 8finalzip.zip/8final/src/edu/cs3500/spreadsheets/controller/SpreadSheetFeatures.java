package edu.cs3500.spreadsheets.controller;

import java.io.IOException;

import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.Formula;
import edu.cs3500.spreadsheets.model.Worksheet;
import edu.cs3500.spreadsheets.view.IView;

/**
 * An interface representing all of the functionality that an editable
 * spreadsheet has.
 * this interface does not have access to any swing components.
 */
public interface SpreadSheetFeatures {

  /**
   * Creates a view from the controller. Needed in order to create a view
   * in the main method.
   */
  void setView(IView view) throws IOException;

  // set the contents in a model
  void setC(Coord c, String f);
}
