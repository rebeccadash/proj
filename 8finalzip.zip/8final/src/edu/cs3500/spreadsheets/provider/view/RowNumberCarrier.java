package edu.cs3500.spreadsheets.provider.view;

import java.awt.Component;
import java.awt.Font;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

/**
 * Makes a new JTable that contains the values for the row numbers. Will align with the actual cell
 * location for that row in the face of scrolling.
 */
public class RowNumberCarrier extends JTable implements PropertyChangeListener, TableModelListener {
  private JTable main;

  /**
   * Constructor for the RowNumberCarrier class.
   *
   * @param table the JTable model in which this is applying the scrollbar and row headers to.
   */
  public RowNumberCarrier(JTable table) {
    main = table;
    main.getModel();
    setFocusable(false);
    setAutoCreateColumnsFromModel(false);

    setSelectionModel(main.getSelectionModel());
    TableColumn column = new TableColumn();
    column.setHeaderValue("   ");
    addColumn(column);
    column.setCellRenderer(new RowRender());

    getColumnModel().getColumn(0).setPreferredWidth(45);
    setPreferredScrollableViewportSize(getPreferredSize());
  }

  /*
   *  Get the rows from main.
   */
  @Override
  public int getRowCount() {
    return main.getRowCount();
  }

  @Override
  public int getRowHeight(int row) {
    int rowHeight = main.getRowHeight(row);
    if (rowHeight != super.getRowHeight(row)) {
      super.setRowHeight(row, rowHeight);
    }
    return rowHeight;
  }

  @Override
  public void tableChanged(TableModelEvent e)
  {
    revalidate();
  }


  /*
   * Implement the PropertyChangeListener
   */
  public void propertyChange(PropertyChangeEvent e) {
    //  Keep the row table in sync with the main table

    if ("selectionModel".equals(e.getPropertyName())) {
      setSelectionModel(main.getSelectionModel());
    }

    if ("rowHeight".equals(e.getPropertyName())) {
      repaint();
    }

    if ("model".equals(e.getPropertyName())) {
      main.getModel().addTableModelListener(this);
      revalidate();
    }
  }

  /*
   *  Use the row number as the header.
   */
  @Override
  public Object getValueAt(int row, int column) {
    return Integer.toString(row + 1);
  }

  /*
   *  Make the row headers uneditable.
   */
  @Override
  public boolean isCellEditable(int row, int column) {
    return false;
  }

  /*
   *  Renders the rows as the headers of the rows.
   */
  private class RowRender extends DefaultTableCellRenderer {
    public RowRender() {
      setHorizontalAlignment(JLabel.CENTER);
    }

    public Component getTableCellRendererComponent(
            JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
      JTableHeader header = table.getTableHeader();
      setBackground(header.getBackground());
      setFont(header.getFont());
      if (isSelected) {
        setFont(getFont().deriveFont(Font.BOLD));
      }
      setText((value == null) ? "" : value.toString());
      return this;
    }
  }
}