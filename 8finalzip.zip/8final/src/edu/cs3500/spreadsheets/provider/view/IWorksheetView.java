package edu.cs3500.spreadsheets.provider.view;

import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.io.IOException;

/**
 * Interface for the view which holds all the methods for plausible functionality which individual
 * view classes implement.
 */
public interface IWorksheetView {

  /**
   * Renders the model depending on individual class implementation. Will either form the JFrame
   * window in GraphicsView or return the String format for TextualView
   *
   * @throws IOException if the model fails to render for some reason.
   */
  void render() throws IOException;

  /**
   * Provide the view with an action listener for
   * the button that should cause the program to
   * process a command. This is so that when the button
   * is pressed, control goes to the action listener
   *
   * @param actionEvent any type of action made by user in the editable view frame.
   */
  void setCommandButtonListener(ActionListener actionEvent) throws IOException;

  /**
   * Provides the view with a mouselistener.
   *
   * @param mouseEvent any type of mouse event made by user in the frame.
   */
  void setMouseListener(MouseListener mouseEvent);

  /**
   * Signal the view to draw itself.
   */
  void refresh();

  /**
   * Sets the data in whichever format is required, either in textual String format of original
   * formula or in the evaluated Values.
   *
   * @param object passed in String or Value
   * @param row    row of the cell
   * @param col    column of the cell
   */
  void setData(Object object, int row, int col);

  /**
   * Method to obtain the column index of the selected cell.
   * @return the selected cell's column's index
   */
  int retrieveSelectedCol();

  /**
   * Method to obtain the row index of the selected cell.
   * @return the selected cell's row's index
   */
  int retrieveSelectedRow();

  /**
   * Displays the textual version of the cell in the text box. (i.e. equivalent to the original
   * cell entry: "=(SUM 1 2 3)".
   *
   * @paramto Display string to be displayed.
   */
  void displaySelected(String display);

  /**
   * Method to retrieve the cell's contents from editor to pass to controller (i.e
   * formulas, references, values) (Ex. "=(SUM 9 5)")
   * @return the String representation of the user's entry into a cell.
   */
  String getTextEntry();

  /**
   * Transmit an error message to the view, in case the command could not be processed correctly.
   *
   * @param error error to be passed and returned.
   */
  void showErrorMessage(String error);

}
