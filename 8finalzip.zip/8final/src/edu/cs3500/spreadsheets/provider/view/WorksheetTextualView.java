package edu.cs3500.spreadsheets.provider.view;

import edu.cs3500.spreadsheets.model.Coord;

import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.io.IOException;

/**
 * The Worksheet Textual View is the textual view of how files are read and can be saved.
 */
public class WorksheetTextualView implements IWorksheetView {

  //TODO: PrintWriter class will be a convenient Appendable
  // this will actually write files onto the disk

  //TODO: render DOESN'T have to reproduce comments or specific formatting
  // or print back cells in their original order

  private Appendable appendable;
  private StringBuilder lineBuilder = new StringBuilder();

  /**
   * Constructor for the WorksheetTextualView.
   * @param appendable the appendable object that will hold the output.
   */
  public WorksheetTextualView(Appendable appendable) {
    if (appendable == null) {
      throw new IllegalArgumentException("Invalid Appendable!");
    }
    this.appendable = appendable;
  }

  @Override
  public String toString() {
    return this.appendable.toString();

  }

  @Override
  public void render() throws IOException {
    this.appendable.append(lineBuilder);
  }

  @Override
  public void setCommandButtonListener(ActionListener actionEvent) {
  }

  @Override
  public void setMouseListener(MouseListener mouseListener) {

  }

  @Override
  public void refresh() {
  }

  @Override
  public void setData(Object object, int row, int col) {
    lineBuilder.append((new Coord(row, col)).toString());
    lineBuilder.append(" ");
    lineBuilder.append(object);
    lineBuilder.append("\n");

  }

  @Override
  public int retrieveSelectedCol() {
    return 0;
  }

  @Override
  public int retrieveSelectedRow() {
    return 0;
  }

  @Override
  public void displaySelected(String display) {

  }

  @Override
  public String getTextEntry() {
    return null;
  }

  @Override
  public void showErrorMessage(String error) {

  }
}
