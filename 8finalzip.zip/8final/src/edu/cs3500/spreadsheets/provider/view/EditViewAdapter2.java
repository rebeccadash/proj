package edu.cs3500.spreadsheets.provider.view;

import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.io.IOException;

import edu.cs3500.spreadsheets.controller.SpreadSheetFeatures;
import edu.cs3500.spreadsheets.view.IView;

public class EditViewAdapter2 implements IWorksheetView {

  private IView v;
  private SpreadSheetFeatures f;


  public EditViewAdapter2(IView view) {
    this.v = view;
  }

  @Override
  public void render() throws IOException {
    v.render();
  }

  @Override
  public void setCommandButtonListener(ActionListener actionEvent) throws IOException {

  }

  @Override
  public void setMouseListener(MouseListener mouseEvent) {

  }

  @Override
  public void refresh() {

  }

  @Override
  public void setData(Object object, int row, int col) {


  }

  @Override
  public int retrieveSelectedCol() {
    return 0;
  }

  @Override
  public int retrieveSelectedRow() {
    return 0;
  }

  @Override
  public void displaySelected(String display) {

  }

  @Override
  public String getTextEntry() {
    return null;
  }

  @Override
  public void showErrorMessage(String error) {

  }
}
