package edu.cs3500.spreadsheets.provider.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;



public class WorksheetEditableView extends JFrame implements IWorksheetView {
  private JPanel buttonPanel;
  //todo: changed
  protected JTextField input;
  private JButton commandButton, addRow, addCol;
  protected JTable table;
  private int rows;
  private int columns;
  private int selCol = -1;
  private int selRow = -1;
  private JLabel label1, label2;

  public WorksheetEditableView() {
    super();
    this.setTitle("gOOD SpreadSheet");
    this.setSize(1000, 500);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(new BorderLayout());
    rows = 30;
    columns = 20;
    table = new JTable(rows, columns);

    JScrollPane scrollPaneVertical = new JScrollPane(table);
    JTable rowTable = new RowNumberCarrier(table);
    scrollPaneVertical.setRowHeaderView(rowTable);
    scrollPaneVertical.setCorner(JScrollPane.UPPER_LEFT_CORNER, rowTable.getTableHeader());
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    this.add(scrollPaneVertical);

    //button panel
    buttonPanel = new JPanel();
    buttonPanel.setLayout(new FlowLayout());
    this.add(buttonPanel, BorderLayout.SOUTH);

    //input textfield
    input = new JTextField(50);

    //buttons
    commandButton = new JButton("Enter");
    addRow = new JButton("Row+");
    addRow.addActionListener((ActionEvent e) -> {
      this.addRow();
    });
    addCol = new JButton("Col+");
    addCol.addActionListener((ActionEvent e) -> {
      this.addCol();
    });

    //mouse listener
    table.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(MouseEvent e) {
        super.mouseClicked(e);
        selCol = table.getSelectedColumn();
        selRow = table.getSelectedRow();
        label2.setText(colIndexToName(retrieveSelectedCol()) + retrieveSelectedRow() + "\t");
      }
    });

    //display panel
    label1 = new JLabel();
    label1.setText("<html><h2>Selected Cells:  </h2></html>");
    label2 = new JLabel();
    label2.setText("<html><h2>" + colIndexToName(retrieveSelectedCol()) + retrieveSelectedRow() +
            "</h2></html>");

    buttonPanel.add(label1);
    buttonPanel.add(label2);

    //add the panel elements
    buttonPanel.add(commandButton);
    buttonPanel.add(input);
    buttonPanel.add(addRow);
    buttonPanel.add(addCol);

    table.setDefaultEditor(Object.class, null);

    this.pack();

  }

  private static String colIndexToName(int index) {
    StringBuilder ans = new StringBuilder();
    while (index > 0) {
      int colNum = (index - 1) % 26;
      ans.insert(0, Character.toChars('A' + colNum));
      index = (index - colNum) / 26;
    }
    return ans.toString();
  }

  @Override
  public void setMouseListener(MouseListener mouseEvent) {
    table.addMouseListener(mouseEvent);
  }

  @Override
  public void setCommandButtonListener(ActionListener actionEvent) {
    commandButton.addActionListener(actionEvent);
  }

  @Override
  public void refresh() {
    this.repaint();
  }

  @Override
  public void render() throws IOException {
    this.setVisible(true);
  }

  // adds 10 rows at the bottom of the spreadsheet
  private void addRow() {
    this.rows += 10;
    DefaultTableModel model = (DefaultTableModel) table.getModel();
    model.setRowCount(this.rows);
    this.repaint();
  }

  // adds 5 columns to the right of the spreadsheet
  private void addCol() {
    this.columns += 5;
    DefaultTableModel model = (DefaultTableModel) table.getModel();
    model.setColumnCount(this.columns);
    this.repaint();
  }

  public int retrieveSelectedRow() {
    return selRow + 1;
  }

  public int retrieveSelectedCol() {
    return selCol + 1;
  }

  public void displaySelected(String toDisplay) {
    if (table.getModel().getValueAt(selRow, selCol) != null) {
      input.setText(toDisplay);
    } else {
      input.setText("");
    }
  }

  @Override
  public String getTextEntry() {
    String entry = this.input.getText();
    this.input.setText("");
    return entry;
  }

  @Override
  public void setData(Object object, int row, int col) {
    table.getModel().setValueAt(object, col - 1, row - 1);
  }

  @Override
  public void showErrorMessage(String error) {
    JOptionPane.showMessageDialog(this, error, "Error", JOptionPane.ERROR_MESSAGE);

  }
}
