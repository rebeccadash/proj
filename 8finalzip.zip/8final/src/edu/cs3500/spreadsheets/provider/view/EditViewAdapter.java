package edu.cs3500.spreadsheets.provider.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

import edu.cs3500.spreadsheets.controller.SpreadSheetFeatures;
import edu.cs3500.spreadsheets.model.ReadOnlyModel;
import edu.cs3500.spreadsheets.model.Worksheet;
import edu.cs3500.spreadsheets.view.IView;

public class EditViewAdapter implements IView {

  public WorksheetEditableView theView;

  public EditViewAdapter(WorksheetEditableView view) {
    theView = view;
  }

  @Override
  public void render() throws IOException {
    theView.render();
  }

  @Override
  public String getInputString() {
    return theView.getTextEntry();
  }

  @Override
  public void clearInString() {
    theView.displaySelected("");
  }

  @Override
  public void addFeatures(SpreadSheetFeatures sFeatures) throws IOException {
    theView.setMouseListener(new MouseListener() {
      @Override
      public void mouseClicked(MouseEvent mouseEvent) {
        try {
          theView.displaySelected(theView.table.getModel().getValueAt(theView.retrieveSelectedCol(), theView.retrieveSelectedRow()).toString());
          System.out.println("mouse clicked");
        } catch (NullPointerException n) {
          theView.input.setText("No content at this cell ");
        }
      }

      @Override
      public void mousePressed(MouseEvent mouseEvent) {

      }

      @Override
      public void mouseReleased(MouseEvent mouseEvent) {

      }

      @Override
      public void mouseEntered(MouseEvent mouseEvent) {

      }

      @Override
      public void mouseExited(MouseEvent mouseEvent) {

      }
    });
    theView.setCommandButtonListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent actionEvent) {
        theView.setData(theView.getTextEntry(), theView.retrieveSelectedCol(), theView.retrieveSelectedRow());
      }
    });

  }

  @Override
  public void resetFocus() {
  }

  @Override
  public void setModel(Worksheet readOnlyModel) {

  }

}
