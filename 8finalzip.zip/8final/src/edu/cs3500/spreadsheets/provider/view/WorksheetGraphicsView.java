package edu.cs3500.spreadsheets.provider.view;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;


/**
 * Contains the table using J Swing JTable. Represents the view of the spreadsheet model.
 */
public class WorksheetGraphicsView extends JFrame implements IWorksheetView {
  private JTable table;
  private int rows;
  private int columns;

  /**
   * Constructor for WorksheetGraphicsView.
   */
  public WorksheetGraphicsView() {
    super();
    this.setTitle("gOOD SpreadSheet");
    this.setSize(1000, 500);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(new BorderLayout());
    table = new JTable(40, 52);
    JTableHeader header = table.getTableHeader();
    this.add(header, BorderLayout.NORTH);

    JScrollPane scrollPaneVertical = new JScrollPane(table);
    JTable rowTable = new RowNumberCarrier(table);
    scrollPaneVertical.setRowHeaderView(rowTable);
    scrollPaneVertical.setCorner(JScrollPane.UPPER_LEFT_CORNER, rowTable.getTableHeader());
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    this.add(scrollPaneVertical);
    this.pack();

  }

  /**
   * Makes the table visible in the JFrame.
   */
  @Override
  public void render() {
    this.setVisible(true);
  }

  @Override
  public void setCommandButtonListener(ActionListener actionEvent) {

  }

  @Override
  public void setMouseListener(MouseListener mouseEvent) {

  }

  @Override
  public void refresh() {
    this.repaint();
  }

  /**
   * At the appropriate given cell index, will update the value in the table with the value at the
   * corresponding point in the model.
   *
   * @param obj value value of cell.
   * @param row row of cell using 1 index.
   * @param col column of cell using 1 index.
   */
  @Override
  public void setData(Object obj, int col, int row) {
    table.getModel().setValueAt(obj, col - 1, row - 1);
  }

  @Override
  public int retrieveSelectedCol() {
    return 0;
  }

  @Override
  public int retrieveSelectedRow() {
    return 0;
  }

  @Override
  public void displaySelected(String display) {

  }

  @Override
  public String getTextEntry() {
    return null;
  }

  @Override
  public void showErrorMessage(String error) {

  }

}
