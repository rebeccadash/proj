package edu.cs3500.spreadsheets.provider.model;

import edu.cs3500.spreadsheets.model.Worksheet;

/**
 * Represents a cell of a spreadsheet. Can be empty, a value, or a formula.
 */
public interface Cell {

  /**
   * Evaluates the Cell into an Value.
   * @param w given worksheet that you are working on.
   * @return Value - value of the cell after evaluation.
   */
  Value evaluate(Worksheet w);

  /**
   * Acceptor for the visitor pattern.
   * @param w Given worksheet that is being worked on.
   * @param visitor Visitor function to visit desired cell type.
   * @param <R> type of return of the visitor function
   * @return return type of the visitor function.
   */
  <R> R accept(Worksheet w, CellVisitor<R> visitor);

}