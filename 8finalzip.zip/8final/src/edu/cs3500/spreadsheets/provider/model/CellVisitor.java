package edu.cs3500.spreadsheets.provider.model;


import java.util.List;

import edu.cs3500.spreadsheets.model.Function;
import edu.cs3500.spreadsheets.model.Worksheet;

/**
 * An abstracted function object for processing any {@link Cell}.
 * @param <R> The return type of this function
 */
public interface CellVisitor<R> {

  /**
   * Process a boolean value.
   * @param b the boolean value
   * @return the desired result.
   */
  R visitValueBool(boolean b);

  /**
   * Process a String value.
   * @param s the String value.
   * @return the desired result.
   */
  R visitValueString(String s);

  /**
   * Process a double value.
   * @param d the double value.
   * @return the desired result.
   */
  R visitValueDouble(double d);

  /**
   *  Process a reference value.
   * @param w the worksheet being worked on
   * @param referenceList the reference formula.
   * @return the desired result.
   */
  R visitRef(Worksheet w, List<Coord> referenceList);

  /**
   *  Process a formula.
   * @param w the worksheet being worked on
   * @param fx the function object
   * @param elements the list of ICells.
   * @return the desired result.
   */
  R visitFormula(Worksheet w, Function fx, List<Cell> elements);

}
