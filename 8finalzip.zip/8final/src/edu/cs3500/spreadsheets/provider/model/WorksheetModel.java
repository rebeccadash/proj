package edu.cs3500.spreadsheets.provider.model;

import java.util.List;

import edu.cs3500.spreadsheets.model.Cell;
import edu.cs3500.spreadsheets.model.Coord;

/**
 * The WorksheetModel interface contains all the methods the Worksheet needs to function within the
 * Beyond Good program. A Worksheet would be able to add a cell to itself when a method is called
 * and change the contents of each cell.
 */
public interface WorksheetModel {

  /**
   * Creates a cell in the worksheet with the given contents at the given row and column.
   *
   * @param row the row index where the cell is located.
   * @param col the column index where the cell is located.
   * @param contents the contents within the cell.
   */
  void createCell(int col, int row, String contents);

  /**
   * The cell's contents in the worksheet at the given row and column with the given contents.
   *
   * @param row the row index where the cell is located.
   * @param col the column index where the cell is located.
   * @param contents the contents within the cell.
   */
  void changeCells(int col, int row, String contents);


  /**
   * The getter method for an Cell within a worksheet.
   * @param col column of cell in worksheet
   * @param row row of cell in a worksheet
   * @return Cell object
   */

  Cell retrieveCell(int col, int row);

  /**
   * The getter method for an Cell within a worksheet.
   * @param coord a String in the form of a Letter and a Number indicating column and row.
   * @return Cell object.
   */
  Cell retrieveCell(String coord);


  List<Coord> getAllKeys();
}