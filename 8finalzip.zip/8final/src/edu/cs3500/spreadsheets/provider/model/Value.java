package edu.cs3500.spreadsheets.provider.model;


/**
 * Represents a value in a cell  A value is one of:.
 * <ul>
 *   <li>A boolean</li>
 *   <li>A number</li>
 *   <li>A String</li>
 * </ul>
 *
 * <p>
 *   Processing of each type of value will be done through the visitor pattern: see
 *   {@link CellVisitor}.
 * </p>
 */
public interface Value extends Cell {

}
