package edu.cs3500.spreadsheets.provider.model;


import java.util.List;

import edu.cs3500.spreadsheets.model.Cell;
import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.Worksheet;
import edu.cs3500.spreadsheets.sexp.Parser;
import edu.cs3500.spreadsheets.sexp.SexpToFormulaVisitor;

public class ModelAdapter implements WorksheetModel {

  public Worksheet ws;

  ModelAdapter(Worksheet wS) {
    this.ws = wS;
  }

  @Override
  public void createCell(int col, int row, String contents) {
    ws.setContents(new Coord(col, row), Parser.parse(contents).accept(new SexpToFormulaVisitor()));
  }

  @Override
  public void changeCells(int col, int row, String contents) {
    ws.changeContents(Parser.parse(contents).accept(new SexpToFormulaVisitor()), new Coord(col, row));
  }

  @Override
  public Cell retrieveCell(int col, int row) {
    return ws.getCellAt(new Coord(col, row));
  }

  @Override
  public Cell retrieveCell(String coord) {
    return ws.getCellAt(new Coord(coord));
  }

  @Override
  public List<Coord> getAllKeys() {
    return null;
  }
}
