//package edu.cs3500.spreadsheets.provider.controller;
//
//import java.io.IOException;
//
//import edu.cs3500.spreadsheets.controller.Controller;
//import edu.cs3500.spreadsheets.controller.SpreadSheetFeatures;
//import edu.cs3500.spreadsheets.provider.view.EditViewAdapter;
//import edu.cs3500.spreadsheets.provider.view.EditViewAdapter2;
//import edu.cs3500.spreadsheets.provider.view.IWorksheetView;
//import edu.cs3500.spreadsheets.provider.view.WorksheetEditableView;
//import edu.cs3500.spreadsheets.view.IView;
//
//public class ControllerAdapter implements IController{
//
//  private IWorksheetView pView;
//
//
//  //set view needs something that isA IView
//  private SpreadSheetFeatures sF;
//
//
//  public ControllerAdapter(SpreadSheetFeatures sFeatures, IWorksheetView view) {
//    this.sF = sFeatures;
//    pView = view;
//
//for (Coord c : myModel.getAllCells())
//pView.setCell(...)
////  }
//
//  @Override
//  public void go() throws IOException {
//    sF.setView(new EditViewAdapter(pView));
//  }
//
//}
