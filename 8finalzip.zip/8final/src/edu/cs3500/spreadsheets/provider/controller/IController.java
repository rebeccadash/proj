package edu.cs3500.spreadsheets.provider.controller;

import java.io.IOException;

/**
 * The controller interface for the spreadsheets.
 * The functions here have been designed to give
 * control to the controller, and the primary
 * operation for the controller.
 */

public interface IController {
  /**
   * Start the program, i.e. give control to the controller
   */
  void go() throws IOException;

}
