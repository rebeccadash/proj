package edu.cs3500.spreadsheets.view;

import java.awt.Adjustable;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.BoxLayout;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.ValueString;
import edu.cs3500.spreadsheets.model.Worksheet;


/**
 * Represents the Panel that will be created that will be the graph.
 *
 */
public class GridPanel extends JPanel {
  private int colCount = 1;
  private int rowCount = 1;
  private int cellWidth = 100;
  private int cellHeight = 25;
  private int screenWidth;
  private int screenHeight;
  JPanel jp;

  /**
   * Represents the Panel that will be created that will be the graph.
   *
   */
  public Worksheet getReadOnlyModel() {
    return readOnlyModel;
  }

  private Worksheet readOnlyModel;
  private JFrame frame;
  protected JButton check;

  protected JButton delete;

  protected JButton revert;

  public JTextField getInput() {
    return input;
  }

  private JTextField input;
  private final Map<JLabel, Coord> where;

  public int addingRow;
  public int addingCol;

  public String labelText;

  public Map<JLabel, Coord> getWhere() {
    return where;
  }


  /**
   * Represents the Panel that will be created that will be the graph.
   *
   * @param screenW       height of the screen.
   * @param screenH       width of the screen.
   * @param readOnlyModel the read only model that will be rendered.
   * @param frame         the JFrame.
   */
  public GridPanel(int screenW, int screenH, Worksheet readOnlyModel, JFrame frame) {
    this.where = new HashMap<>();
    this.screenWidth = screenW;
    this.screenHeight = screenH;
    this.readOnlyModel = readOnlyModel;
    this.frame = frame;
  }


  class ScrollListener implements AdjustmentListener {
    public void adjustmentValueChanged(AdjustmentEvent evt) {
      Adjustable source = evt.getAdjustable();
      int maxValue = source.getMaximum();
      int currValue = source.getValue();
      int scrollLength = source.getVisibleAmount();
      int orientation = source.getOrientation();
      // TODO fix scrolling
      if (currValue + scrollLength >= maxValue) {
        if (orientation == Adjustable.VERTICAL) {
          createEmptyOnBottom(screenWidth, screenHeight).setAlignmentY(screenHeight);


        }
        if (orientation == Adjustable.HORIZONTAL) {

          System.out.println("side reached");


        }

      }
    }
  }


  private JLabel createGridLabel(String strText, boolean isHeader) {
    JLabel gridLabel = new JLabel(strText);
    gridLabel.setPreferredSize(new Dimension(cellWidth, cellHeight));
    if (isHeader) {
      gridLabel.setBackground(Color.lightGray);
    } else {
      gridLabel.setBackground(Color.white);
    }
    gridLabel.setHorizontalAlignment(SwingConstants.CENTER);
    gridLabel.setOpaque(true);
    return (gridLabel);
  }

  private JTextField createTextField() {
    input = new JTextField();
    input.setHorizontalAlignment(SwingConstants.LEFT);
    input.setBackground(Color.white);
    input.setOpaque(true);


    input.setPreferredSize(new Dimension(cellWidth, cellHeight));
    return input;
  }

  private JButton createButton() {
    check = new JButton("Validate Input");
    return check;
  }


  private JButton deleteButton() {
    delete = new JButton("Delete Contentents");
    return delete;
  }

  private JButton revert() {
    revert = new JButton("x");
    return revert;
  }


  protected JPanel createGridPanel(int screenW, int screenH) {
    labelText = "";
    jp = new JPanel();
    int c = 150;
    colCount = c;
    boolean isHeader;
    int r = (screenH / cellHeight);
    rowCount = r;
    JPanel container = new JPanel();
    container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
    JPanel textPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    textPanel.setPreferredSize(new Dimension(screenWidth, cellHeight + 10));
    textPanel.add(createTextField());
    textPanel.add(createButton());
    textPanel.add(deleteButton());
    textPanel.add(revert());

    JPanel gridPanel = new JPanel();
    gridPanel.setPreferredSize(new Dimension(cellWidth * (c + 1), cellHeight * (r + 1)));
    GridLayout layout = new GridLayout(r + 1, c + 1);
    layout.setHgap(1);
    layout.setVgap(1);
    gridPanel.setLayout(layout);
    // for each row
    for (int i = 0; i < r + 1; i++) {
      addingRow++;
      // for each column
      for (int j = 0; j < c + 1; j++) {
        addingCol++;
        labelText = "";
        isHeader = false;
        // if it is the first row and first column leave blank
        if (j == 0 && i == 0) {
          isHeader = true;
        }
        // if it is the first row label the columns
        else if (i == 0) {
          labelText = Coord.colIndexToName(j);
          isHeader = true;
        }
        // if it is the first column label the rows
        else if (j == 0) {
          labelText = i + "";
          isHeader = true;
        }
        // otherwise display the cell contents
        else {
          try {
            if (readOnlyModel.evalCell(new Coord(j, i)).toString().equals("0.0")) {

              labelText = "";
            } else {

              labelText = readOnlyModel.evalCell(new Coord(j, i)).toString();
            }
          } catch (NullPointerException e) {
            labelText = "";
          }
        }
        JLabel gridLabel = createGridLabel(labelText, isHeader);
        gridPanel.add(gridLabel, new Coord(i + 1, j + 1));


        where.put(gridLabel, new Coord(i + 1, j + 1));

      }
    }
    container.add(textPanel);
    container.add(gridPanel);
    //this.setBackground(Color.black);
    this.setPreferredSize(new Dimension(cellWidth * (c + 1), cellHeight * (r + 1) + cellHeight));

    this.add(container);
    //this.add(gridPanel);
    return jp;
  }

  public String getRaw(Coord c) {
    return readOnlyModel.getWs().getCellAt(new Coord(c.col - 1, c.row - 1)).contents.toString();
  }



  // an empty grid to add on when scroll reaches bottom
  private JPanel createEmptyOnBottom(int screenW, int screenH) {
    String labelText;
    int c = 150;
    boolean isHeader;
    int r = (screenH / cellHeight);
    JPanel gridPanel = new JPanel();
    gridPanel.setPreferredSize(new Dimension(cellWidth * (c + 1), cellHeight * (r + 1)));
    GridLayout layout = new GridLayout(r + 1, c + 1);
    layout.setHgap(1);
    layout.setVgap(1);
    gridPanel.setLayout(layout);
    // for each row
    for (int i = 0; i < r + 1; i++) {
      rowCount++;
      // for each column
      for (int j = 0; j < c + 1; j++) {

        labelText = "";
        isHeader = false;
        // if it is the first row and first column leave blank
        if (j == 0) {
          labelText = rowCount + "";
          isHeader = true;
        }
        // otherwise display the cell contents
        else {
          try {
            if (readOnlyModel.evalCell(new Coord(rowCount,
                    colCount + j)).toString().equals("0.0")) {
              labelText = "";
            } else {

              labelText = (readOnlyModel.getCellAt(new Coord(rowCount,
                      colCount + j)).contents.toString());

            }
          } catch (NullPointerException e) {
            labelText = "";
          }
        }
        gridPanel.add(createGridLabel(labelText, isHeader), new Coord(i + 1, j + 1));
        where.put(createGridLabel(labelText, isHeader), new Coord(i + 1, j + 1));

      }
    }
    this.setLayout(new FlowLayout(FlowLayout.LEFT));
    this.setPreferredSize(new Dimension(cellWidth * (colCount + 1),
            cellHeight * (rowCount + 1) + cellHeight));
    this.add(gridPanel);
    return this;
  }

  private JPanel createEmptyOnSide(int screenW, int screenH) {
    String labelText;
    int c = (screenW / cellWidth);
    boolean isHeader;
    int r = (screenH / cellHeight);
    JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT));
    container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
    container.setPreferredSize(new Dimension(screenWidth, cellHeight + 10 + cellHeight * (r + 1)));
    JPanel textPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    textPanel.setPreferredSize(new Dimension(screenWidth, cellHeight + 10));
    textPanel.add(createTextField());
    textPanel.add(createButton());
    textPanel.add(deleteButton());
    JPanel gridPanel = new JPanel();

    gridPanel.setPreferredSize(new Dimension(cellWidth * (c + 1), cellHeight * (r + 1)));
    GridLayout layout = new GridLayout(r + 1, c + 1);
    layout.setHgap(1);
    layout.setVgap(1);
    gridPanel.setLayout(layout);
    // for each row
    for (int i = 0; i < r + 1; i++) {

      // for each column
      for (int j = 0; j < c + 1; j++) {
        colCount++;
        labelText = "";
        isHeader = false;
        // if it is the first row and first column leave blank
        if (i == 0) {
          isHeader = true;
          labelText = Coord.colIndexToName(colCount);
        }
        // otherwise display the cell contents
        else {
          try {
            if (readOnlyModel.getWs().evalCell(new Coord(j + rowCount,
                    colCount)).toString().equals("0.0")) {
              labelText = "";
            } else {
              labelText = (readOnlyModel.getWs().getCellAt(new Coord(j + rowCount,
                      colCount)).contents.toString());
            }
          } catch (NullPointerException e) {
            labelText = "";
          }
        }
        gridPanel.add(createGridLabel(labelText, isHeader), new Coord(i + 1, j + 1));
        where.put(createGridLabel(labelText, isHeader), new Coord(i + 1, j + 1));

      }
    }
    //
    container.add(textPanel);
    container.add(gridPanel);
    this.setLayout(new FlowLayout(FlowLayout.LEFT));
    this.setPreferredSize(new Dimension(cellWidth * (colCount + 1),
            cellHeight * (rowCount + 1) + cellHeight));
    this.add(container);
    return this;
  }

  /**
   * Renders tge actual grid.
   */
  public void drawGrid() {
    // initialize the grid in the frame

    frame.add(createGridPanel(screenWidth, screenHeight));
    // create the scroll panes and bars within
    JScrollPane scrollPane = new JScrollPane(this);
    AdjustmentListener listener = new ScrollListener();
    // horizontal scroll bar
    scrollPane.getHorizontalScrollBar().addAdjustmentListener(listener);
    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    // vertical scroll bar
    scrollPane.getVerticalScrollBar().addAdjustmentListener(listener);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    // sets a buffer of however many pixels
    scrollPane.setBounds(0, 0, screenWidth, screenHeight);

    JPanel contentPane = new JPanel(null);
    contentPane.setPreferredSize(new Dimension(screenWidth, screenHeight));
    contentPane.add(scrollPane);

    frame.setContentPane(contentPane);
    frame.pack();

  }

}
