package edu.cs3500.spreadsheets.view;

import java.io.IOException;

import edu.cs3500.spreadsheets.controller.SpreadSheetFeatures;
import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.ReadOnlyModel;
import edu.cs3500.spreadsheets.model.Worksheet;


/**
 * The textual view of our spreadsheet.
 */
public class TextualView implements IView {
  private Worksheet model;
  private Appendable ap;

  public TextualView(Worksheet model, Appendable ap) throws IOException {
    this.model = model;
    this.ap = ap;
  }

  @Override
  public void render() throws IOException {
    ap.append(buildString());
  }



  @Override
  public String getInputString() {
    return null;
  }

  @Override
  public void clearInString() {
    //not needed in textual view.

  }


  @Override
  public void addFeatures(SpreadSheetFeatures sFeatures) {
    //not needed in textual view.

  }

  @Override
  public void resetFocus() {
    //not needed in textual view.


  }

  @Override
  public void setModel(Worksheet readOnlyModel) {

  }


  // helper aka to String for a model
  private String buildString() {
    String text = "";
    for (Coord c : model.getSpreadsheet().keySet()) {
      text += c.toString() + " " + model.getSpreadsheet().get(c).eval(model.getModel()) + " ";
    }
    return text;
  }
}
