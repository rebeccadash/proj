package edu.cs3500.spreadsheets.view;

import java.io.IOException;

import edu.cs3500.spreadsheets.controller.SpreadSheetFeatures;
import edu.cs3500.spreadsheets.model.ReadOnlyModel;
import edu.cs3500.spreadsheets.model.Worksheet;

/**
 * Represents the different kinds of views for a GUI/text save.
 */
public interface IView {
  /**
   * Renders a model in some manner.
   *
   * @throws IOException if the rendering fails for some reason
   */
  void render() throws IOException;


  /**
   * Purpose: to change the text in the text field from the raw formula to
   * whatever the user happens to type.
   *Get the String from the text field and return it,
   * what the user is intering is going to be in a jTextField
   */
  String getInputString();

  /**
   * If the given formula is not valid. Then cleer the input string.
   */
  void clearInString();


  /**
   * connect to the features interface. this is how it will know to update the cell
   * also to highlight the cell
   */
  void addFeatures(SpreadSheetFeatures sFeatures) throws IOException;


  /**
   * Resets the focus for key handlers.
   */
  void resetFocus();


  void setModel(Worksheet readOnlyModel);
}

