package edu.cs3500.spreadsheets.view;

import javax.swing.JFrame;

import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

import edu.cs3500.spreadsheets.controller.SpreadSheetFeatures;
import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.ReadOnlyModel;
import edu.cs3500.spreadsheets.model.Worksheet;
import edu.cs3500.spreadsheets.sexp.Parser;
import edu.cs3500.spreadsheets.sexp.SexpToFormulaVisitor;

/**
 * The GUI view of a Worksheet.
 */
public class EditView extends JFrame implements IView {
  private int screenWidth;
  private int screenHeight;
  private Worksheet readOnlyModel;
  GridPanel grid;
  JTextField input = new JTextField();
  GuiView g;



  /**
   * Constructor to build a GuiView.
   *
   * @param screenW       is the screen width
   * @param screenH       is the screen height
   * @param readOnlyModel is the readonlymodel to be displayed
   */
  public EditView(int screenW, int screenH, Worksheet readOnlyModel) throws IOException {
    screenWidth = screenW;
    screenHeight = screenH;
    this.readOnlyModel = readOnlyModel;
    grid = new GridPanel(screenW, screenH, readOnlyModel, this);
    this.setTitle("Spreadsheet");
    this.setSize(screenWidth, screenHeight);
    this.setVisible(true);
    this.setResizable(false);
    this.render();
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }


  public EditView(GuiView g) {
    this.g = g;
  }


  @Override
  public void render() throws IOException {
    if (grid.getComponentCount() == 0) {
      grid.drawGrid();
    }
  }

  @Override
  public  String getInputString() {
    return input.getText();
  }

  @Override
  public void clearInString() {
    input.setText("");
  }

  @Override
  public void addFeatures(SpreadSheetFeatures sFeatures) throws IOException {
    for (JLabel lbl : grid.getWhere().keySet()) {

      lbl.addMouseListener(new MouseListener() {

        @Override
        public void mouseClicked(MouseEvent mouseEvent) {
          //lbl.setBackground(Color.white);
          for (JLabel lbl : grid.getWhere().keySet()) {
            if (lbl.getBackground().equals(Color.CYAN)) {
              lbl.setBackground(Color.white);
            }
          }
          lbl.setBackground(Color.cyan);

          //grid.getInput().setText("hi");
          if (mouseEvent.getClickCount() % 2 == 0) {
            lbl.setBackground(Color.white);
          }
          try {
            grid.getInput().setText(grid.getRaw(new Coord(grid.getWhere().get(lbl).row,
                    grid.getWhere().get(lbl).col)));
          }
          catch (NullPointerException n) {
            grid.getInput().setText("No content at this cell");
          }
          if (lbl.getBackground().equals(Color.CYAN)) {
            grid.check.addActionListener(new ActionListener() {
              @Override
              public void actionPerformed(ActionEvent actionEvent) {

                for (JLabel lbl : grid.getWhere().keySet()) {
                  try {
                    if (lbl.getBackground().equals(Color.CYAN)) {
                      if (readOnlyModel.checkForm(grid.getInput().getText())) {
                        lbl.setText(grid.getInput().getText());
                        lbl.setBackground(Color.white);
                        sFeatures.setC(new Coord(grid.getWhere().get(lbl).row,
                                grid.getWhere().get(lbl).col),grid.getInput().getText());
                      }
                    }
                  }
                  catch (IllegalArgumentException e) {
                    input.setText("Could not change given cell");

                  }
                }

              }
            });

            grid.delete.addActionListener(new ActionListener() {
              @Override
              public void actionPerformed(ActionEvent actionEvent) {


                for (JLabel lbl : grid.getWhere().keySet()) {
                  if (lbl.getBackground().equals(Color.CYAN)) {
                    lbl.setText("");
                    lbl.setBackground(Color.white);
                    grid.getInput().setText("");

                  }
                }
                System.out.println("delete pressed");
              }
            });

            grid.revert.addActionListener(new ActionListener() {
              @Override
              public void actionPerformed(ActionEvent actionEvent) {
                for (JLabel lbl : grid.getWhere().keySet()) {
                  if (lbl.getBackground().equals(Color.CYAN)) {
                    lbl.setBackground(Color.white);
                    grid.getInput().setText("");

                  }
                }
              }
            });

          }



        }


        @Override
        public void mousePressed(MouseEvent mouseEvent) {

          //not needed here

        }

        @Override
        public void mouseReleased(MouseEvent mouseEvent) {
          //not needed here
        }

        @Override
        public void mouseEntered(MouseEvent mouseEvent) {
          //not needed here

        }

        @Override
        public void mouseExited(MouseEvent mouseEvent) {
          //not needed here
        }
      });

    }

  }

  @Override
  public void resetFocus() {
    this.setFocusable(true);
    this.requestFocus();
  }

  @Override
  public void setModel(Worksheet r) {
    this.readOnlyModel = r;
    System.out.println(readOnlyModel.evalCell(new Coord(1, 5)).toString());
    try {
      this.render();
    }
    catch (IOException e) {
      throw new IllegalStateException("no");
    }
  }
}

