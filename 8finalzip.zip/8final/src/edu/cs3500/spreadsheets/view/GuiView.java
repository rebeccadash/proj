package edu.cs3500.spreadsheets.view;


import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

import java.awt.Point;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

import edu.cs3500.spreadsheets.controller.SpreadSheetFeatures;
import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.ReadOnlyModel;
import edu.cs3500.spreadsheets.model.Worksheet;


/**
 * The GUI view of a Worksheet.
 */
public class GuiView extends JFrame implements IView {
  private int screenWidth;
  private int screenHeight;
  private Worksheet readOnlyModel;
  GridPanel grid;
  JTextField input = new JTextField();
  //Button check = grid.check;

  public GridPanel getGrid() {
    return grid;
  }

  /**
   * Constructor to build a GuiView.
   *
   * @param screenW       is the screen width
   * @param screenH       is the screen height
   * @param readOnlyModel is the readonlymodel to be displayed
   */
  public GuiView(int screenW, int screenH, Worksheet readOnlyModel) throws IOException {
    screenWidth = screenW;
    screenHeight = screenH;
    this.readOnlyModel = readOnlyModel;
    grid = new GridPanel(screenW, screenH, readOnlyModel, this);
    this.setTitle("Spreadsheet");
    this.setSize(screenWidth, screenHeight);
    this.setVisible(true);
    this.setResizable(false);
    this.render();
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }


  @Override
  public void render() throws IOException {
    grid.drawGrid();
  }

  @Override
  public String getInputString() {
    return grid.getInput().getText();
  }

  @Override
  public void clearInString() {
    input.setText("");
  }


  @Override
  public void addFeatures(SpreadSheetFeatures sFeatures) {
    for (JLabel lbl : grid.getWhere().keySet()) {

      lbl.addMouseListener(new MouseListener() {

        @Override
        public void mouseClicked(MouseEvent mouseEvent) {
          //lbl.setBackground(Color.white);
          for (JLabel lbl : grid.getWhere().keySet()) {
            if (lbl.getBackground().equals(Color.CYAN)) {
              lbl.setBackground(Color.white);
            }
          }
          lbl.setBackground(Color.cyan);
          System.out.println("cell selected");
          //grid.getInput().setText("hi");
          if (mouseEvent.getClickCount() % 2 == 0) {
            lbl.setBackground(Color.white);
          }
          try {
            grid.getInput().setText(grid.getRaw(new Coord(grid.getWhere().get(lbl).row,
                    grid.getWhere().get(lbl).col)));
          } catch (NullPointerException n) {
            grid.getInput().setText("No content at this cell");
          }
        }

        @Override
        public void mousePressed(MouseEvent mouseEvent) {
          //not needed here
        }

        @Override
        public void mouseReleased(MouseEvent mouseEvent) {
          //not needed here

        }

        @Override
        public void mouseEntered(MouseEvent mouseEvent) {
          //not needed here
        }

        @Override
        public void mouseExited(MouseEvent mouseEvent) {
          //not needed here

        }
      });


    }
  }
  @Override
  public void resetFocus() {
    this.setFocusable(true);
    this.requestFocus();
  }

  @Override
  public void setModel(Worksheet readOnlyModel) {

  }

}

