package edu.cs3500.spreadsheets.sexp;

import java.util.ArrayList;
import java.util.List;

import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.Formula;
import edu.cs3500.spreadsheets.model.FormulaVisitorBuildStory;
import edu.cs3500.spreadsheets.model.FormulaVisitorLessThan;
import edu.cs3500.spreadsheets.model.FormulaVisitorProduct;
import edu.cs3500.spreadsheets.model.FormulaVisitorSum;
import edu.cs3500.spreadsheets.model.Function;
import edu.cs3500.spreadsheets.model.Reference;
import edu.cs3500.spreadsheets.model.ValueBoolean;
import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;

/**
 * Parses an Sexp into a Formula Visitor so the correct Formula can be returned.
 */
public class SexpToFormulaVisitor implements SexpVisitor<Formula> {
  @Override
  public Formula visitBoolean(boolean b) {
    return new ValueBoolean(b);
  }

  @Override
  public Formula visitNumber(double num) {
    return new ValueNumber(num);
  }

  @Override
  public Formula visitString(String s) {
    return new ValueString(s);
  }

  @Override
  public Formula visitSList(List<Sexp> list) {
    // if the symbol is a valid function
    // if the list is of size 1, we know that it is a single cell reference//argument
    // TODO - fix reference
    // list.get(0) is an sList-

    String func = list.get(0).toString();
    List<Formula> args = new ArrayList<>();
    for (int i = 1; i < list.size(); i++) {
      args.add(list.get(i).accept(this));
    }
    switch (func) {
      case "SUM":
        return new Function(new FormulaVisitorSum(), args);
      case "PRODUCT":
        return new Function(new FormulaVisitorProduct(), args);
      case "<":
        return new Function(new FormulaVisitorLessThan(), args);
      case "BUILDSTORY":
        return new Function(new FormulaVisitorBuildStory(), args);
      default:
        throw new IllegalArgumentException("incorrect symbol");
    }
  }

  @Override
  public Formula visitSymbol(String str) {
    if (str.contains(":")) {
      String[] parts = str.split(":");
      return new Reference(new Coord(parts[0]), new Coord(parts[1]));
    }
    if (isString(str)) {
      return visitString(str);
    } else {
      return new Reference(new Coord(str));
    }
  }

  // helper to tell if the entire string is alphabetic
  private boolean isString(String s) {
    for (int i = 0; i < s.length(); i++) {
      if (!Character.isAlphabetic(s.charAt(i))) {
        return false;
      }
    }
    return true;
  }
}