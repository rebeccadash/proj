import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

import edu.cs3500.spreadsheets.model.Coord;

/**
 * Tests for the Coord class.
 */
public class TestCoord {
  Coord coordA1 = new Coord(1, 1);
  Coord alsoCoordA1 = new Coord(1, 1);
  Coord coordAAA1 = new Coord(703, 1);
  Coord coordTE24 = new Coord(525, 24);

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalCoords() {
    new Coord(0, 1);
    new Coord(1, -2);
    new Coord(-10, 0);
  }

  @Test
  public void testColNameToIndex() {
    assertEquals(703, Coord.colNameToIndex("AAA"));
    assertEquals(1, Coord.colNameToIndex("A"));
    assertEquals(525, Coord.colNameToIndex("TE"));
  }

  @Test
  public void testColIndexToName() {
    assertEquals("AAA", Coord.colIndexToName(703));
    assertEquals("A", Coord.colIndexToName(1));
  }

  @Test
  public void testCoordToString() {
    assertEquals("A1", coordA1.toString());
    assertEquals("AAA1", coordAAA1.toString());
    assertEquals("TE24", coordTE24.toString());
  }

  @Test
  public void testCoordEquals() {
    assertEquals(true, coordA1.equals(alsoCoordA1));
    assertEquals(true, alsoCoordA1.equals(coordA1));
    assertEquals(false, coordTE24.equals(coordA1));
  }

  @Test
  public void testCoordHash() {
    assertTrue(coordA1.equals(alsoCoordA1) && alsoCoordA1.equals(coordA1));
    assertTrue(coordA1.hashCode() == alsoCoordA1.hashCode());
  }
}
