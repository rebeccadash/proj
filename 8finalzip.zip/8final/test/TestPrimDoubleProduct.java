import org.junit.Test;

import edu.cs3500.spreadsheets.model.PrimDoubleProduct;
import edu.cs3500.spreadsheets.model.ValueBoolean;

import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

public class TestPrimDoubleProduct {
  private PrimDoubleProduct primDoubleProd = new PrimDoubleProduct();
  private ValueString abc = new ValueString("abc");
  private ValueString strOne = new ValueString("one");
  private ValueBoolean boolTrue = new ValueBoolean(true);
  private ValueBoolean boolFalse = new ValueBoolean(false);
  private ValueNumber one = new ValueNumber(1);
  private ValueNumber negTenPointFive = new ValueNumber(-10.5);

  @Test
  public void testPrimDoubleProductVals() {
    assertEquals(1.0, primDoubleProd.visitValString(abc));
    assertEquals(1.0, primDoubleProd.visitValString(strOne));
    assertEquals(1.0, primDoubleProd.visitValBool(boolTrue));
    assertEquals(1.0, primDoubleProd.visitValBool(boolFalse));
    assertEquals(1.0, primDoubleProd.visitValNum(one));
    assertEquals(-10.5, primDoubleProd.visitValNum(negTenPointFive));
  }
}
