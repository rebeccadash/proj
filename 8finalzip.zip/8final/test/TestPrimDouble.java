import org.junit.Test;

import edu.cs3500.spreadsheets.model.PrimDouble;
import edu.cs3500.spreadsheets.model.ValueBoolean;

import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;

import static junit.framework.TestCase.assertEquals;

public class TestPrimDouble {
  private PrimDouble primDouble = new PrimDouble();
  private ValueString abc = new ValueString("abc");
  private ValueString strOne = new ValueString("one");
  private ValueBoolean boolTrue = new ValueBoolean(true);
  private ValueBoolean boolFalse = new ValueBoolean(false);
  private ValueNumber one = new ValueNumber(1);
  private ValueNumber negTenPointFive = new ValueNumber(-10.5);

  @Test
  public void testPrimDoubleVals() {
    assertEquals(0.0, primDouble.visitValString(abc));
    assertEquals(0.0, primDouble.visitValString(strOne));
    assertEquals(0.0, primDouble.visitValBool(boolTrue));
    assertEquals(0.0, primDouble.visitValBool(boolFalse));
    assertEquals(1.0, primDouble.visitValNum(one));
    assertEquals(-10.5, primDouble.visitValNum(negTenPointFive));
  }
}
