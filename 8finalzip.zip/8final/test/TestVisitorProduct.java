import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import edu.cs3500.spreadsheets.model.Formula;
import edu.cs3500.spreadsheets.model.FormulaVisitorProduct;
import edu.cs3500.spreadsheets.model.FormulaVisitorSum;
import edu.cs3500.spreadsheets.model.Value;
import edu.cs3500.spreadsheets.model.ValueBoolean;

import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;
import edu.cs3500.spreadsheets.model.WorksheetModel;

import static junit.framework.TestCase.assertEquals;

/**
 * Tests for the product visitor.
 */
public class TestVisitorProduct {
  FormulaVisitorProduct product = new FormulaVisitorProduct();
  WorksheetModel model = new WorksheetModel();

  // numbers
  Value twelve = new ValueNumber(12);
  Value one = new ValueNumber(1);
  Value two = new ValueNumber(2);
  Value three = new ValueNumber(3);
  Value four = new ValueNumber(4);
  Value strHello = new ValueString("hello");
  Value boolTrue = new ValueBoolean(true);
  Value negTenPointFive = new ValueNumber(-10.5);

  // list of args
  List<Formula> twelveTimesTwelve;
  List<Formula> oneTHRUfour;
  List<Formula> withStringAndBool;
  List<Formula> withNegAndDecimal;

  @Before
  public void initialize() {
    twelveTimesTwelve = new ArrayList<>();
    twelveTimesTwelve.add(twelve);
    twelveTimesTwelve.add(twelve);

    oneTHRUfour = new ArrayList<>();
    oneTHRUfour.add(one);
    oneTHRUfour.add(two);
    oneTHRUfour.add(three);
    oneTHRUfour.add(four);

    withStringAndBool = new ArrayList<>();
    withStringAndBool.add(three);
    withStringAndBool.add(strHello);
    withStringAndBool.add(boolTrue);
    withStringAndBool.add(four);

    withNegAndDecimal = new ArrayList<>();
    withNegAndDecimal.add(negTenPointFive);
    withNegAndDecimal.add(two);
  }

    @Test
  public void testProduct() {
    assertEquals(new ValueNumber(144.0), product.apply(twelveTimesTwelve, model));
    assertEquals(new ValueNumber(24.0), product.apply(oneTHRUfour, model));
    assertEquals(new ValueNumber(12.0), product.apply(withStringAndBool, model));
    assertEquals(new ValueNumber(-21.0), product.apply(withNegAndDecimal, model));
  }
}
