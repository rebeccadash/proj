import org.junit.Test;

import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertTrue;
import static junit.framework.TestCase.assertEquals;

import edu.cs3500.spreadsheets.model.Cell;
import edu.cs3500.spreadsheets.model.ValueBoolean;
import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;
import edu.cs3500.spreadsheets.model.WorksheetModel;

/**
 * Tests for Cell class.
 */
// TODO -- fix types
public class TestCell {
  private WorksheetModel model = new WorksheetModel();
  private Cell c1 = new Cell(new ValueNumber(2));
  private Cell alsoc1 = new Cell(new ValueNumber(2));
  private Cell c2 = new Cell(new ValueBoolean(true));
  private Cell c3 = new Cell(new ValueString("hello"));
  private Cell c4 = new Cell(new ValueString("!"));

  @Test
  public void testGetContents() {
    assertEquals(new ValueNumber(2.0), c1.getContents());
    assertEquals(new ValueBoolean(true), c2.getContents());
    assertEquals(new ValueString("hello"), c3.getContents());
    assertEquals(new ValueString("!"), c4.getContents());
  }

  @Test
  public void testCellEval() {
    assertEquals(new ValueNumber(2.0), c1.eval(model));
    assertEquals(new ValueBoolean(true), c2.eval(model));
    assertEquals(new ValueString("hello"), c3.eval(model));
    assertEquals(new ValueString("!"), c4.eval(model));
  }

  @Test
  public void testEquals() {
    assertFalse(c1.equals(c2));
    assertTrue(c1.equals(alsoc1));
    assertTrue(alsoc1.equals(c1));
    assertFalse(c3.equals(c4));
  }

  @Test
  public void testHash() {
    assertEquals(true, c1.equals(alsoc1) && alsoc1.equals(c1));
    assertTrue(c1.hashCode() == alsoc1.hashCode());
  }
}
