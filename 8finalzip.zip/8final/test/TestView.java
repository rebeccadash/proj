import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;

import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.Formula;
import edu.cs3500.spreadsheets.model.FormulaVisitorLessThan;
import edu.cs3500.spreadsheets.model.FormulaVisitorSum;
import edu.cs3500.spreadsheets.model.Function;
import edu.cs3500.spreadsheets.model.Reference;
import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;
import edu.cs3500.spreadsheets.model.Worksheet;
import edu.cs3500.spreadsheets.model.WorksheetModel;
import edu.cs3500.spreadsheets.model.WorksheetReader;
import edu.cs3500.spreadsheets.view.TextualView;

import static org.junit.Assert.assertEquals;

/**
 * Tests the view of the spreadsheet.
 */
public class TestView {

  @Test
  public void testView() throws IOException {
    Worksheet ws = new WorksheetModel.WorksheetBuilder().createWorksheet();
    ws.setContents(new Coord(1, 1), new ValueNumber(9.0));
    ws.setContents(new Coord(1, 2), new ValueNumber(20.0));
    ws.setContents(new Coord(1, 3), new ValueString("hi"));
    ws.setContents(new Coord(1, 4), new ValueString("bye"));
    StringBuilder sb = new StringBuilder();
    TextualView tv = new TextualView(ws, sb);
    tv.render();
    assertEquals("A2 20.0 A1 9.0 A4 bye A3 hi ", sb.toString());
  }

  @Test
  public void testView1() throws IOException {
    Worksheet ws = new WorksheetModel.WorksheetBuilder().createWorksheet();
    ArrayList<Formula> forTest = new ArrayList<>();
    forTest.add(new ValueNumber(1.0));
    forTest.add(new ValueNumber(4.9));
    ws.setContents(new Coord(1, 1), new ValueNumber(1.6));
    ws.setContents(new Coord(1, 2), new ValueNumber(20.0));
    ws.setContents(new Coord(2, 1), new Function(new FormulaVisitorSum(), forTest));
    ws.setContents(new Coord(2, 2), new ValueString("bye"));
    StringBuilder sb = new StringBuilder();
    TextualView tv = new TextualView(ws, sb);
    tv.render();
    assertEquals("A2 20.0 A1 1.6 B2 bye B1 5.9 ", sb.toString());
  }

  @Test
  public void testView2() throws IOException {
    Worksheet ws = new WorksheetModel.WorksheetBuilder().createWorksheet();

    ws.setContents(new Coord(1, 1), new ValueNumber(1.6));
    ws.setContents(new Coord(1, 2), new ValueNumber(20.0));
    ws.setContents(new Coord(2, 1), new Reference(new Coord(1, 1)));
    ws.setContents(new Coord(2, 2), new ValueString("bye"));
    StringBuilder sb = new StringBuilder();
    TextualView tv = new TextualView(ws, sb);
    tv.render();
    assertEquals("A2 20.0 A1 1.6 B2 bye B1 1.6 ", sb.toString());
  }


  @Test
  public void testViewModel() throws IOException {
    Worksheet ws = new WorksheetModel.WorksheetBuilder().createWorksheet();
    ws.setContents(new Coord(1, 1), new ValueNumber(1.6));
    StringBuilder sb = new StringBuilder();
    TextualView tv = new TextualView(ws, sb);
    tv.render();
    Worksheet w2 = WorksheetReader.read(new WorksheetModel.WorksheetBuilder(),
            new StringReader(sb.toString()));
    assertEquals(ws.getCellAt(new Coord(1, 1)), w2.getCellAt(new Coord(1, 1)));
  }

  @Test
  public void testViewModel1() throws IOException {
    Worksheet ws = new WorksheetModel.WorksheetBuilder().createWorksheet();
    ws.setContents(new Coord(2, 1), new ValueString("hi"));
    StringBuilder sb = new StringBuilder();
    TextualView tv = new TextualView(ws, sb);
    tv.render();
    Worksheet w2 = WorksheetReader.read(new WorksheetModel.WorksheetBuilder(),
            new StringReader(sb.toString()));
    assertEquals(ws.getCellAt(new Coord(2, 1)), w2.getCellAt(new Coord(2, 1)));
  }


  @Test
  public void testView3() throws IOException {
    Worksheet ws = new WorksheetModel.WorksheetBuilder().createWorksheet();
    ArrayList<Formula> forTest = new ArrayList<>();
    forTest.add(new ValueNumber(1.0));
    forTest.add(new ValueNumber(4.9));
    ws.setContents(new Coord(1, 1), new ValueNumber(1.6));
    ws.setContents(new Coord(1, 2), new ValueNumber(20.0));
    ws.setContents(new Coord(1, 3), new Reference(new Coord(1, 1)));
    ws.setContents(new Coord(1, 4), new Function(new FormulaVisitorSum(), forTest));
    StringBuilder sb = new StringBuilder();
    TextualView tv = new TextualView(ws, sb);
    tv.render();
    assertEquals("A2 20.0 A1 1.6 A4 5.9 A3 1.6 ", sb.toString());
  }

  @Test
  public void testView4() throws IOException {
    Worksheet ws = new WorksheetModel.WorksheetBuilder().createWorksheet();
    ArrayList<Formula> forTest = new ArrayList<>();
    forTest.add(new ValueNumber(3.0));
    forTest.add(new ValueNumber(7.0));
    ws.setContents(new Coord(1, 1), new ValueNumber(1.6));
    ws.setContents(new Coord(1, 2), new ValueNumber(20.0));
    ws.setContents(new Coord(1, 3), new Reference(new Coord(1, 2)));
    ws.setContents(new Coord(1, 4), new Function(new FormulaVisitorLessThan(), forTest));
    StringBuilder sb = new StringBuilder();
    TextualView tv = new TextualView(ws, sb);
    tv.render();
    assertEquals("A2 20.0 A1 1.6 A4 true A3 20.0 ", sb.toString());
  }

  @Test
  public void testView5() throws IOException {
    Worksheet ws = new WorksheetModel.WorksheetBuilder().createWorksheet();
    ArrayList<Formula> forTest = new ArrayList<>();
    forTest.add(new ValueNumber(1.0));
    forTest.add(new ValueNumber(4.9));
    ws.setContents(new Coord(1, 1), new ValueNumber(1.6));
    ws.setContents(new Coord(1, 2), new ValueNumber(20.0));
    ws.setContents(new Coord(1, 3), new Reference(new Coord(1, 1), new Coord(1, 2)));
    ws.setContents(new Coord(1, 4), new ValueString(""));
    StringBuilder sb = new StringBuilder();
    TextualView tv = new TextualView(ws, sb);
    tv.render();
    assertEquals("A2 20.0 A1 1.6 A4  A3   ", sb.toString());
  }
}