import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import edu.cs3500.spreadsheets.model.Formula;
import edu.cs3500.spreadsheets.model.FormulaVisitorLessThan;
import edu.cs3500.spreadsheets.model.Value;
import edu.cs3500.spreadsheets.model.ValueBoolean;

import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;
import edu.cs3500.spreadsheets.model.WorksheetModel;

import static junit.framework.TestCase.assertEquals;

/**
 * Tests for the less than visitor.
 */
public class TestVisitorLessThan {
  FormulaVisitorLessThan lessThan = new FormulaVisitorLessThan();
  WorksheetModel model = new WorksheetModel();

  // numbers
  Value twelve = new ValueNumber(12);
  Value one = new ValueNumber(1);
  Value strOne = new ValueString("one");

  // list of args
  List<Formula> oneLtTwelve;
  List<Formula> twelveLtOne;
  List<Formula> oneAndOne;
  List<Formula> numStrNumOne;

  @Before
  public void initialize() {
    oneLtTwelve = new ArrayList<>();
    oneLtTwelve.add(one);
    oneLtTwelve.add(twelve);

    twelveLtOne = new ArrayList<>();
    twelveLtOne.add(twelve);
    twelveLtOne.add(one);

    oneAndOne = new ArrayList<>();
    oneAndOne.add(one);
    oneAndOne.add(strOne);

    numStrNumOne = new ArrayList<>();
    numStrNumOne.add(one);
    numStrNumOne.add(strOne);
    numStrNumOne.add(one);
  }

  @Test
  public void testLessThan() {
    assertEquals(new ValueBoolean(true), lessThan.apply(oneLtTwelve, model));
    assertEquals(new ValueBoolean(false), lessThan.apply(twelveLtOne, model));
    assertEquals(new ValueBoolean(false), lessThan.apply(oneAndOne, model));
  }
}