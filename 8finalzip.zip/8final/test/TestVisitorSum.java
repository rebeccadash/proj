import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import edu.cs3500.spreadsheets.model.Formula;
import edu.cs3500.spreadsheets.model.FormulaVisitorSum;
import edu.cs3500.spreadsheets.model.Value;
import edu.cs3500.spreadsheets.model.ValueBoolean;
import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;
import edu.cs3500.spreadsheets.model.WorksheetModel;

import static junit.framework.TestCase.assertEquals;

/**
 * Tests for the sum visitor.
 */
public class TestVisitorSum {
  FormulaVisitorSum sum = new FormulaVisitorSum();
  WorksheetModel model = new WorksheetModel();

  // numbers
  Value twelve = new ValueNumber(12);
  Value one = new ValueNumber(1);
  Value two = new ValueNumber(2);
  Value three = new ValueNumber(3);
  Value four = new ValueNumber(4);
  Value strHello = new ValueString("hello");
  Value boolTrue = new ValueBoolean(true);
  Value negTenPointFive = new ValueNumber(-10.5);

  // lists of args
  List<Formula> twelvePlusTwelve;
  List<Formula> oneTHRUfour;
  List<Formula> withStringAndBool;
  List<Formula> withNegAndDecimal;

  @Before
  public void initialize() {
    twelvePlusTwelve = new ArrayList<>();
    twelvePlusTwelve.add(twelve);
    twelvePlusTwelve.add(twelve);

    oneTHRUfour = new ArrayList<>();
    oneTHRUfour.add(one);
    oneTHRUfour.add(two);
    oneTHRUfour.add(three);
    oneTHRUfour.add(four);

    withStringAndBool = new ArrayList<>();
    withStringAndBool.add(three);
    withStringAndBool.add(strHello);
    withStringAndBool.add(boolTrue);
    withStringAndBool.add(four);

    withNegAndDecimal = new ArrayList<>();
    withNegAndDecimal.add(negTenPointFive);
    withNegAndDecimal.add(two);
  }

  @Test
  public void testSum() {
    assertEquals(new ValueNumber(24.0), sum.apply(twelvePlusTwelve, model));
    assertEquals(new ValueNumber(10.0), sum.apply(oneTHRUfour, model));
    assertEquals(new ValueNumber(7.0), sum.apply(withStringAndBool, model));
    assertEquals(new ValueNumber(-8.5), sum.apply(withNegAndDecimal, model));
  }
}
