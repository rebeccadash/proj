import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertTrue;

import edu.cs3500.spreadsheets.model.Value;
import edu.cs3500.spreadsheets.model.ValueString;
import edu.cs3500.spreadsheets.model.WorksheetModel;

public class TestValueString {
  WorksheetModel model = new WorksheetModel();
  Value strHello = new ValueString("hello");
  Value strAlsoHello = new ValueString("hello");
  Value strHelloMix = new ValueString("hELLo");
  Value strHi = new ValueString("hi");
  Value strWithNums = new ValueString("h3ll0");
  Value strWithCaps = new ValueString("bUiLdExCeL");
  Value strExclaim = new ValueString("!");
  Value strEquals = new ValueString("=");
  Value strOne = new ValueString("1");

  @Test
  public void testStrEval() {
    assertEquals(new ValueString("hello"), strHello.evaluate(model));
    assertEquals(new ValueString("h3ll0"), strWithNums.evaluate(model));
    assertEquals(new ValueString("bUiLdExCeL"), strWithCaps.evaluate(model));
    assertEquals(new ValueString("!"), strExclaim.evaluate(model));
    assertEquals(new ValueString("="), strEquals.evaluate(model));
    assertEquals(new ValueString("1"), strOne.evaluate(model));
  }

  @Test
  public void testStrAccept() {

  }

  @Test
  public void testStrEquals() {
    assertTrue(strHello.equals(strAlsoHello));
    assertTrue(strAlsoHello.equals(strHello));
    assertFalse(strHello.equals(strHelloMix));
  }

  @Test
  public void testStrHash() {
    assertTrue(strHello.equals(strAlsoHello) && strAlsoHello.equals(strHello));
    assertTrue(strHello.hashCode() == strAlsoHello.hashCode());
  }
}
