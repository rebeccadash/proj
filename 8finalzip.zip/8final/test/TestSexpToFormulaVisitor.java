import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static junit.framework.TestCase.assertEquals;

import edu.cs3500.spreadsheets.model.Formula;
import edu.cs3500.spreadsheets.model.ValueBoolean;

import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;
import edu.cs3500.spreadsheets.sexp.SexpToFormulaVisitor;
import edu.cs3500.spreadsheets.model.FormulaVisitorSum;

/**
 * Test for the Sexp to Formula visitor.
 */
// TODO - all tests rip
public class TestSexpToFormulaVisitor {
  SexpToFormulaVisitor sexpVisitor = new SexpToFormulaVisitor();
  Formula bTrue;
  Formula bFalse;
  Formula num1234;
  Formula num10;
  Formula hello;
  FormulaVisitorSum sum;
  ArrayList list;

  @Before
  public void setUp() {
    this.bTrue = new ValueBoolean(true);
    this.bFalse = new ValueBoolean(false);
    this.num1234 = new ValueNumber(1234);
    this.num10 = new ValueNumber(10);
    this.hello = new ValueString("hello");
    this.sum = new FormulaVisitorSum();
    this.list = new ArrayList<>();
    list.add(sum);
    list.add(num1234);
    list.add(num10);

  }

  @Test
  public void testVisitBoolean() {
    assertEquals(bTrue, sexpVisitor.visitBoolean(true));
    assertEquals(bFalse, sexpVisitor.visitBoolean(true));
  }

  @Test
  public void testVisitNumber() {
    assertEquals(num1234, sexpVisitor.visitNumber(1234));
  }

  @Test
  public void testVisitString() {
    assertEquals(hello, sexpVisitor.visitString("hello"));
  }

  @Test
  public void testVisitSList() {
    assertEquals(list, sexpVisitor.visitNumber(1244));
  }

  //  // should be a reference?
  //  @Test
  //  public void testVisitSSymbol() {
  //
  //  }
}
