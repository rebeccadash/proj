import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertEquals;

import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.Reference;

/**
 * Tests for the Reference class.
 */
public class TestReference {
  // coordinates
  Coord coordA1 = new Coord(1, 1);
  Coord coordA2 = new Coord(1, 2);
  Coord coordB1 = new Coord(2, 1);
  Coord coordB2 = new Coord(2, 2);
  Coord coordD3 = new Coord(4, 1);

  //references
  Reference a1TOb2 = new Reference(coordA1, coordB2);
  Reference onlyD3 = new Reference(coordD3);
  List<Coord> listA1toB2;
  List<Coord> listOnlyD3;

  @Before
  public void reset() {
    this.listA1toB2 = new ArrayList<>();
    this.listA1toB2.add(coordA1);
    this.listA1toB2.add(coordA2);
    this.listA1toB2.add(coordB1);
    this.listA1toB2.add(coordB2);

    this.listOnlyD3 = new ArrayList<>();
    this.listOnlyD3.add(coordD3);
  }

  @Test
  public void testGetGroup() {
    assertEquals(listA1toB2, a1TOb2.getGroup());
    assertEquals(listOnlyD3, onlyD3.getGroup());
  }

  @Test
  public void testRefToString() {
    // getGroup returns a list of Coords --> strings
    assertEquals("[A1, A2, B1, B2]", listA1toB2.toString());
    assertEquals("[D3]", listOnlyD3.toString());
  }

  //  // tests if the reference is accepting a visitor
  //  // TODO - test accept
  //  @Test
  //  public void testRefAccept() {
  //  }
  //
  //  // tests for evaluating references
  //  // TODO - test evaluate
  //  @Test
  //  public void testRefEval() {
  //  }
  //
  //  // tests for checking if the reference is cyclic
  //  // TODO - test cyclic
  //  @Test
  //  public void testCyclic() {
  //  }
}
