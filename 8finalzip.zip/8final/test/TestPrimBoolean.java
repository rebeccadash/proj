import org.junit.Test;

import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.PrimBool;
import edu.cs3500.spreadsheets.model.Reference;
import edu.cs3500.spreadsheets.model.ValueBoolean;

import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;

import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertTrue;

public class TestPrimBoolean {
  private PrimBool primBool = new PrimBool();
  private ValueString abc = new ValueString("abc");
  private ValueBoolean boolTrue = new ValueBoolean(true);
  private ValueBoolean boolFalse = new ValueBoolean(false);
  private ValueNumber one = new ValueNumber(1);
  private Reference ref = new Reference(new Coord(1, 1));

  @Test
  public void testPrimBoolVals() {
    assertFalse(primBool.visitValString(abc));
    assertTrue(primBool.visitValBool(boolTrue));
    assertFalse(primBool.visitValBool(boolFalse));
    assertFalse(primBool.visitValNum(one));
  }

  @Test
  public void testPrimBoolRef() {

  }
}
