import org.junit.Test;

import edu.cs3500.spreadsheets.model.PrimString;
import edu.cs3500.spreadsheets.model.ValueBoolean;

import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;

import static junit.framework.TestCase.assertEquals;

public class TestPrimString {
  private PrimString primString = new PrimString();
  private ValueString abc = new ValueString("abc");
  private ValueString strOne = new ValueString("one");
  private ValueBoolean boolTrue = new ValueBoolean(true);
  private ValueBoolean boolFalse = new ValueBoolean(false);
  private ValueNumber one = new ValueNumber(1);

  @Test
  public void testPrimStringVals() {
    assertEquals("abc", primString.visitValString(abc));
    assertEquals("one", primString.visitValString(strOne));
    assertEquals("", primString.visitValBool(boolTrue));
    assertEquals("", primString.visitValBool(boolFalse));
    assertEquals("", primString.visitValNum(one));
  }
}
