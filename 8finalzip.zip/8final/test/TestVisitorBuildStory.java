import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import edu.cs3500.spreadsheets.model.Formula;
import edu.cs3500.spreadsheets.model.FormulaVisitorBuildStory;
import edu.cs3500.spreadsheets.model.PrimString;
import edu.cs3500.spreadsheets.model.Value;

import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;
import edu.cs3500.spreadsheets.model.WorksheetModel;

import static junit.framework.TestCase.assertEquals;

/**
 * Tests for the build story visitor.
 */
public class TestVisitorBuildStory {
  FormulaVisitorBuildStory buildStory = new FormulaVisitorBuildStory();
  WorksheetModel model = new WorksheetModel();

  // values
  Value lets = new ValueString("Let's");
  Value build = new ValueString("build");
  Value excel = new ValueString("Excel");
  Value exclaim = new ValueString("!");
  Value strTwo = new ValueString("two");
  Value numTwo = new ValueNumber(2.0);
  Value strNumTwo = new ValueString("2");
  Value symbolPlus = new ValueString("+");

  // lists of args
  List<Formula> buildExcel;
  List<Formula> twoPlusTwo;
  List<Formula> twoPlusTwoAgain;

  @Before
  public void initialize() {
    buildExcel = new ArrayList<>();
    buildExcel.add(lets);
    buildExcel.add(build);
    buildExcel.add(excel);
    buildExcel.add(exclaim);

    twoPlusTwo = new ArrayList<>();
    twoPlusTwo.add(strTwo);
    twoPlusTwo.add(symbolPlus);
    twoPlusTwo.add(numTwo);

    twoPlusTwoAgain = new ArrayList<>();
    twoPlusTwoAgain.add(strTwo);
    twoPlusTwoAgain.add(symbolPlus);
    twoPlusTwoAgain.add(strNumTwo);
  }

  @Test
  public void testBuildStory() {
    assertEquals("Let's build Excel !",
            buildStory.apply(buildExcel, model).accept(new PrimString()));
    assertEquals("two + 2",
            buildStory.apply(twoPlusTwoAgain, model).accept(new PrimString()));
    assertEquals("two + ",
            buildStory.apply(twoPlusTwo, model).accept(new PrimString()));

  }
}
