import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertTrue;

import edu.cs3500.spreadsheets.model.Value;
import edu.cs3500.spreadsheets.model.ValueBoolean;
import edu.cs3500.spreadsheets.model.WorksheetModel;

/**
 * Tests for the different kinds of Values.
 */
// TODO -- fix types
public class TestValueBoolean {
  WorksheetModel model = new WorksheetModel();
  Value boolTrue = new ValueBoolean(true);
  Value boolFalse = new ValueBoolean(false);
  Value boolAlsoTrue = new ValueBoolean(true);

  @Test
  public void testBooleanEval() {
    assertEquals(new ValueBoolean(true), boolTrue.evaluate(model));
    assertEquals(new ValueBoolean(false), boolFalse.evaluate(model));
  }

  // TODO -- test
  @Test
  public void testBooleanAccept() {
  }

  @Test
  public void testBooleanEquals() {
    assertTrue(boolTrue.equals(boolAlsoTrue));
    assertTrue(boolAlsoTrue.equals(boolTrue));
    assertFalse(boolTrue.equals(boolFalse));
  }

  @Test
  public void testBooleanHash() {
    assertTrue(boolTrue.equals(boolAlsoTrue) && boolAlsoTrue.equals(boolTrue));
    assertTrue(boolTrue.hashCode() == boolAlsoTrue.hashCode());
  }
}
