import org.junit.Before;
import org.junit.Test;

import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.ValueString;
import edu.cs3500.spreadsheets.model.Worksheet;
import edu.cs3500.spreadsheets.model.WorksheetModel;

import static junit.framework.TestCase.assertEquals;

/**
 * Tests for the Worksheet model.
 */
public class TestModel<R> {
  private WorksheetModel.WorksheetBuilder builder;

  @Before
  public void setUp() {
    // builder
    this.builder = new WorksheetModel.WorksheetBuilder();
  }

  // create cell tests
  @Test
  public void testCreate() {
    builder.createCell(1, 1, "hi");
    Worksheet model = builder.createWorksheet();
    assertEquals(new ValueString("hi"), model.getCellAt(new Coord(1, 1)).getContents());
  }

  @Test
  public void testCreateWs() {
    builder.createCell(1, 1, "hi");
    builder.createCell(1, 2, "hi");
    builder.createCell(2, 1, "hi");
    builder.createCell(2, 2, "no");
    Worksheet model = builder.createWorksheet();
    assertEquals(new ValueString("no"), model.getCellAt(new Coord(2, 2)).getContents());
  }

  @Test
  public void testSum1() {
    builder.createCell(1, 1, "4");
    builder.createCell(1, 2, "3");
    builder.createCell(2, 1, "=(SUM 2 5)");
    Worksheet model = builder.createWorksheet();
    assertEquals(new ValueNumber(7), model.evalCell(new Coord(2, 1)));
  }

  @Test
  public void testSum2() {
    builder.createCell(1, 1, "4");
    builder.createCell(1, 2, "3");
    builder.createCell(2, 1, "=(SUM A1 A2)");
    Worksheet model = builder.createWorksheet();
    assertEquals(new ValueNumber(7), model.evalCell(new Coord(2, 1)));
  }


  //testwith non numbers
  @Test
  public void testSum3() {
    builder.createCell(1, 1, "9");
    builder.createCell(1, 2, "3");
    builder.createCell(1, 3, "1");
    builder.createCell(1, 4, "=(SUM A1:A3)");
    Worksheet model = builder.createWorksheet();
    assertEquals(new ValueNumber(13), model.evalCell(new Coord(1, 4)));
  }
}

//
//  //no numbers
//  @Test
//  public void testSum4() {
//    builder.createCell(1, 2, "bye");
//    builder.createCell(1, 3, "hi");
//    builder.createCell(1, 4, "=(SUM A1:A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(0), model.evalCell(new Coord(1, 4)));
//  }
//
//  // inside call too
//  @Test
//  public void testSum5() {
//    builder.createCell(1, 1, "4");
//    builder.createCell(1, 2, "3");
//    builder.createCell(1, 3, "1");
//    builder.createCell(1, 4, "=(SUM (SUM A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(8), model.evalCell(new Coord(1, 4)));
//  }
//
//  @Test
//  public void testSum6() {
//    builder.createCell(1, 1, "10");
//    builder.createCell(1, 2, "3");
//    builder.createCell(1, 3, "1");
//    builder.createCell(1, 4, "=(SUM (SUM A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(14), model.evalCell(new Coord(1, 4)));
//  }
//
//  @Test
//  public void testSum60() {
//    builder.createCell(1, 1, "no");
//    builder.createCell(1, 2, "3");
//    builder.createCell(1, 3, "1");
//    builder.createCell(1, 4, "=(SUM (SUM A2 A3) A1)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(4), model.evalCell(new Coord(1, 4)));
//  }
//
//  @Test
//  public void testSum7() {
//    builder.createCell(1, 1, "no");
//    builder.createCell(1, 2, "haha");
//    builder.createCell(1, 3, "hi");
//    builder.createCell(1, 4, "=(SUM (SUM A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(0), model.evalCell(new Coord(1, 4)));
//  }
//
//  @Test
//  public void testSum8() {
//    builder.createCell(1, 1, "true");
//    builder.createCell(1, 2, "haha");
//    builder.createCell(1, 3, "3");
//    builder.createCell(1, 4, "=(SUM (SUM A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(3), model.evalCell(new Coord(1, 4)));
//  }
//
//  @Test
//  public void testSum9() {
//
//
//    builder.createCell(1, 3, "3");
//    builder.createCell(1, 4, "=(SUM (SUM A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(3), model.evalCell(new Coord(1, 4)));
//  }
//
//  @Test
//  public void testSum10() {
//    builder.createCell(1, 4, "=(SUM (SUM A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(0), model.evalCell(new Coord(1, 4)));
//  }
//
//
//  @Test
//  public void testRef() {
//    builder.createCell(1, 1, "4");
//    builder.createCell(2, 1, "A1");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(4), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testRef2() {
//    builder.createCell(1, 1, "B1");
//    builder.createCell(2, 1, "1");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(1), model.evalCell(new Coord(1, 1)));
//  }
//
//  @Test
//  public void testRef3() {
//    builder.createCell(1, 1, "B1");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueString(""), model.evalCell(new Coord(1, 1)));
//  }
//
//  //testing prod
//  @Test
//  public void testProd0() {
//    builder.createCell(1, 1, "4");
//    builder.createCell(1, 2, "3");
//    builder.createCell(2, 1, "=(PRODUCT A1 A2)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(12), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testProd1() {
//    builder.createCell(1, 1, "4");
//    builder.createCell(1, 2, "A1");
//    builder.createCell(2, 1, "=(PRODUCT A1 A2)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(16), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testProd2() {
//    builder.createCell(1, 1, "0");
//    builder.createCell(1, 2, "3");
//    builder.createCell(2, 1, "=(PRODUCT A1 A2)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(0), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testProd3() {
//    builder.createCell(1, 1, "3");
//    builder.createCell(1, 2, "4");
//    builder.createCell(1, 3, "3");
//    builder.createCell(2, 1, "=(PRODUCT A1:A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(36), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testProd4() {
//    builder.createCell(2, 1, "=(PRODUCT A1:A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(0), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testProd5() {
//    builder.createCell(1, 1, "true");
//    builder.createCell(1, 2, "5");
//    builder.createCell(1, 3, "7");
//    builder.createCell(2, 1, "=(PRODUCT A1:A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(35), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testProd6() {
//    builder.createCell(1, 1, "true");
//    builder.createCell(1, 2, "5");
//    builder.createCell(2, 1, "7");
//    //a ref that doesnt exist
//    builder.createCell(2, 1, "=(PRODUCT A4)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(0), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testProd7() {
//    builder.createCell(1, 1, "3");
//    builder.createCell(1, 2, "5");
//    builder.createCell(1, 3, "7");
//    builder.createCell(1, 4, "=(PRODUCT (PRODUCT A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(105), model.evalCell(new Coord(1, 4)));
//  }
//
//  @Test
//  public void testProd8() {
//    builder.createCell(1, 1, "0");
//    builder.createCell(1, 2, "5");
//    builder.createCell(2, 1, "7");
//    //a ref that doesnt exist
//    builder.createCell(2, 1, "=(PRODUCT (PRODUCT A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(0), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testProd9() {
//    builder.createCell(1, 1, "7");
//    builder.createCell(1, 2, "5");
//    builder.createCell(1, 3, "7");
//    builder.createCell(2, 1, "=(PRODUCT (PRODUCT A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(245), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testProd10() {
//    builder.createCell(1, 1, "1");
//    builder.createCell(1, 2, "2");
//    builder.createCell(2, 1, "7");
//    builder.createCell(2, 2, "=(PRODUCT (SUM A1 A2) B1)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(21), model.evalCell(new Coord(2, 2)));
//  }
//
//  @Test
//  public void testProd11() {
//    builder.createCell(1, 1, "3");
//    builder.createCell(1, 2, "2");
//    builder.createCell(2, 1, "7");
//    //a ref that doesnt exist
//    builder.createCell(2, 2, "=(SUM (PRODUCT A1 A2) B1)");
//    Worksheet model = builder.createWorksheet();
//
//    assertEquals(new ValueNumber(13), model.evalCell(new Coord(2, 2)));
//
//  }
//
//  @Test
//  public void testProd12() {
//    builder.createCell(1, 1, "0");
//    builder.createCell(1, 2, "2");
//    builder.createCell(2, 1, "7");
//    builder.createCell(2, 2, "=(SUM (PRODUCT A1 A2) B1)");
//    Worksheet model = builder.createWorksheet();
//
//    assertEquals(new ValueNumber(7), model.evalCell(new Coord(2, 2)));
//  }
//
//  @Test
//  public void testProd13() {
//
//    //a ref that doesnt exist
//    builder.createCell(2, 1, "=(SUM (PRODUCT A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueNumber(0), model.evalCell(new Coord(2, 1)));
//  }
//
//
//  //testing less than
//  @Test
//  public void testLThan() {
//    builder.createCell(1, 1, "4");
//    builder.createCell(1, 2, "3");
//    builder.createCell(2, 1, "=(< A1 A2)");
//    Worksheet model = builder.createWorksheet();
//
//    assertEquals(new ValueBoolean(false), model.evalCell(new Coord(2, 1)));
//  }
//
//  //testing less than
//  @Test
//  public void testLThan1() {
//    builder.createCell(1, 1, "4");
//    builder.createCell(1, 2, "hi");
//    builder.createCell(2, 1, "=(< A1 A2)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueBoolean(false), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testLThan2() {
//    builder.createCell(1, 1, "4");
//    builder.createCell(1, 2, "3");
//    builder.createCell(1, 3, "4");
//    builder.createCell(2, 1, "=(< (SUM A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueBoolean(false), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testLThan3() {
//    builder.createCell(1, 2, "3");
//    builder.createCell(1, 3, "4");
//    builder.createCell(2, 1, "=(< (SUM A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//
//    assertEquals(new ValueBoolean(true), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testLThan4() {
//    builder.createCell(1, 1, "21");
//    builder.createCell(1, 2, "3");
//    builder.createCell(1, 3, "3415");
//    builder.createCell(2, 1, "=(< (PRODUCT A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//
//    assertEquals(new ValueBoolean(true), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testLThan5() {
//    builder.createCell(1, 1, "3");
//    builder.createCell(1, 2, "2");
//    builder.createCell(1, 3, "41");
//    builder.createCell(2, 1, "=(< (PRODUCT A1 A2) A3)");
//    Worksheet model = builder.createWorksheet();
//
//    assertEquals(new ValueBoolean(true), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testBstory() {
//    builder.createCell(1, 1, "hi");
//    builder.createCell(1, 2, "hello");
//    builder.createCell(2, 1, "=(BUILDSTORY A1 A2)");
//    Worksheet model = builder.createWorksheet();
//
//    assertEquals(new ValueString("hi hello "), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testBstory1() {
//    builder.createCell(1, 1, "hi");
//    builder.createCell(1, 2, "1");
//    builder.createCell(2, 1, "=(BUILDSTORY A1 A2)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueString("hi  "), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testBstory2() {
//    builder.createCell(1, 1, "hi");
//    builder.createCell(1, 2, "bye");
//    builder.createCell(1, 3, "haha");
//    builder.createCell(2, 1, "=(BUILDSTORY A1:A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueString("hi bye haha "), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testBstory3() {
//    builder.createCell(1, 1, "hi");
//    builder.createCell(1, 2, "haha");
//    builder.createCell(2, 1, "=(BUILDSTORY A1:A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueString("hi haha  "), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testBstory4() {
//    builder.createCell(1, 1, "3");
//    builder.createCell(1, 2, "bye");
//    builder.createCell(1, 3, "7");
//    builder.createCell(2, 1, "=(BUILDSTORY A1:A3)");
//    Worksheet model = builder.createWorksheet();
//    assertEquals(new ValueString(" bye  "), model.evalCell(new Coord(2, 1)));
//  }
//
//  @Test
//  public void testBstory5() {
//    builder.createCell(1, 1, "3");
//    builder.createCell(1, 2, "bye");
//    builder.createCell(1, 3, "7");
//    builder.createCell(2, 1, "=(BUILDSTORY (PRODUCT A1 A3) A2)");
//    Worksheet model = builder.createWorksheet();
//
//    assertEquals(new ValueString("bye "), model.evalCell(new Coord(2, 1)));
//  }
//}
