import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static junit.framework.TestCase.assertFalse;

import edu.cs3500.spreadsheets.model.Value;

import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.WorksheetModel;

public class TestValueDouble {
  private WorksheetModel model = new WorksheetModel();
  private Value one = new ValueNumber(1.0);
  private Value alsoOne = new ValueNumber(1);
  private Value oneHundred = new ValueNumber(100.0);
  private Value negThreePoint14 = new ValueNumber(-3.14);
  private Value twentyPoint48 = new ValueNumber(20.48);

  @Test
  public void testNumEval() {
    assertEquals(new ValueNumber(1), one.evaluate(model));
    assertEquals(new ValueNumber(100), oneHundred.evaluate(model));
    assertEquals(new ValueNumber(-3.14), negThreePoint14.evaluate(model));
    assertEquals(new ValueNumber(20.48), twentyPoint48.evaluate(model));
  }

  // TODO - test accept
  @Test
  public void testNumAccept() {
  }

  @Test
  public void testNumEquals() {
    assertTrue(one.equals(alsoOne));
    assertTrue(alsoOne.equals(one));
    assertFalse(one.equals(oneHundred));
    assertEquals(false, one.equals(oneHundred));
  }

  @Test
  public void testNumHash() {
    assertTrue(one.equals(alsoOne) && alsoOne.equals(one));
    assertTrue(one.hashCode() == alsoOne.hashCode());
  }
}
