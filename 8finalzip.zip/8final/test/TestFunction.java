import org.junit.Before;

import static junit.framework.TestCase.assertEquals;

import java.util.ArrayList;
import java.util.List;

import edu.cs3500.spreadsheets.model.Formula;
import edu.cs3500.spreadsheets.model.Function;

import edu.cs3500.spreadsheets.model.ValueNumber;
import edu.cs3500.spreadsheets.model.WorksheetModel;
import edu.cs3500.spreadsheets.model.FormulaVisitorBuildStory;
import edu.cs3500.spreadsheets.model.FormulaVisitorLessThan;
import edu.cs3500.spreadsheets.model.FormulaVisitorProduct;
import edu.cs3500.spreadsheets.model.FormulaVisitorSum;

public class TestFunction {
  // model
  WorksheetModel model = new WorksheetModel();
  // visitors
  FormulaVisitorSum sumVisitor = new FormulaVisitorSum();
  FormulaVisitorProduct productVisitor = new FormulaVisitorProduct();
  FormulaVisitorLessThan lessThanVisitor = new FormulaVisitorLessThan();
  FormulaVisitorBuildStory buildStoryVisitor = new FormulaVisitorBuildStory();

  // numbers
  Formula one = new ValueNumber(1);
  Formula two = new ValueNumber(2);
  Formula three = new ValueNumber(3);

  // list of numbers
  List<Formula> list1THRU3;

  @Before
  public void buildList() {
    this.list1THRU3 = new ArrayList<>();
    list1THRU3.add(one);
    list1THRU3.add(two);
    list1THRU3.add(three);
  }

  // add only numbers
  Function add1THRU3 = new Function(new FormulaVisitorSum(), list1THRU3);
  // multiply only numbers
  Function multiply1THRU3 = new Function(new FormulaVisitorProduct(), list1THRU3);
  // compare only numbers
  Function lessthan1THRU3 = new Function(new FormulaVisitorLessThan(), list1THRU3);
  // build story with only numbers
  Function buildstory1THRU3 = new Function(new FormulaVisitorBuildStory(), list1THRU3);

  // === tests start here =====================================================
  // TODO - theres an error
}
